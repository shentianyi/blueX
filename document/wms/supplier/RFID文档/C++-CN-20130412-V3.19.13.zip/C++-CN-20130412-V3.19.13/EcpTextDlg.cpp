// EcpTextDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EcpText.h"
#include "EcpTextDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEcpTextDlg dialog

CEcpTextDlg::CEcpTextDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEcpTextDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEcpTextDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEcpTextDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEcpTextDlg)
	DDX_Control(pDX, IDC_COMBO1, m_listbox1);
	DDX_Control(pDX, IDC_TAB1, m_tab1);
	DDX_Control(pDX, IDC_EDIT7, m_edit7);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEcpTextDlg, CDialog)
	//{{AFX_MSG_MAP(CEcpTextDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB1, OnSelchangeTab1)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEcpTextDlg message handlers

BOOL CEcpTextDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	Init();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEcpTextDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEcpTextDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEcpTextDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CEcpTextDlg::Init()
{
	hCom=INVALID_HANDLE_VALUE;
	sockClient=INVALID_SOCKET;

	HeartCout=0;
	MuitFlag=FALSE;

	CString str11;
	for (int i=1;i<20;i++)
	{
		str11.Format("COM%d",i);
		m_listbox1.InsertString(i-1,str11);
	}
	m_listbox1.SetCurSel(0);
	SetDlgItemText(IDC_EDIT3,"9600");

	m_tab1.ShowWindow(FALSE);
	m_tab1.InsertItem(0,"����1"); 
	m_tab1.InsertItem(1,"����2");
	m_tab1.InsertItem(2,"����3");
	m_tab1.InsertItem(3,"����4");
	m_tab1.InsertItem(4,"����5");
	m_tab1.InsertItem(5,"����6");

	dlg1.Create(IDD_DIALOG1,GetDlgItem(IDC_TAB1));
	dlg2.Create(IDD_DIALOG2,GetDlgItem(IDC_TAB1));
	dlg3.Create(IDD_DIALOG3,GetDlgItem(IDC_TAB1));
	dlg4.Create(IDD_DIALOG4,GetDlgItem(IDC_TAB1));
	dlg5.Create(IDD_DIALOG5,GetDlgItem(IDC_TAB1));//GetDlgItem(IDC_TAB1)
	dlg6.Create(IDD_DIALOG6,GetDlgItem(IDC_TAB1));//GetDlgItem(IDC_TAB1)

	CRect rs; 
	m_tab1.GetClientRect(rs); 
	rs.top+=20; 
	rs.bottom-=4; 
	rs.left+=4; 
	rs.right-=4; 
	
	dlg1.MoveWindow(rs);
	dlg2.MoveWindow(rs);
	dlg3.MoveWindow(rs);
	dlg4.MoveWindow(rs);
	dlg5.MoveWindow(rs);
	dlg6.MoveWindow(rs);

	dlg1.ShowWindow(1);
	dlg2.ShowWindow(0);
	dlg3.ShowWindow(0);
	dlg4.ShowWindow(0);
	dlg5.ShowWindow(0);
	dlg6.ShowWindow(0);

	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(1);
	OnRadio1();

	ElementEnable(IDC_BUTTON2,FALSE);
	ElementEnable(IDC_BUTTON4,FALSE);
	ElementEnable(IDC_BUTTON6,FALSE);

	SetDlgItemText(IDC_EDIT4,"172.16.4.159");
	SetDlgItemText(IDC_EDIT5,"2300");

	SetDlgItemText(IDC_EDIT6,"2300");

	SocketSetOther(NULL,2,5);//������������

}
void CEcpTextDlg::OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if (MuitFlag)
	{
		m_tab1.SetCurSel(1);
		AfxMessageBox("��ֹͣ�࿨���л�");		
		return;
	}
	int nCurSel = m_tab1.GetCurSel(); 
	switch(nCurSel) 
	{ 
	case 0: 
		dlg1.ShowWindow(TRUE); 
		dlg2.ShowWindow(FALSE); 
		dlg3.ShowWindow(FALSE);
		dlg4.ShowWindow(FALSE);
		dlg5.ShowWindow(FALSE);
		dlg6.ShowWindow(FALSE);
		break; 
	case 1: 
		dlg1.ShowWindow(FALSE); 
		dlg2.ShowWindow(TRUE); 
		dlg3.ShowWindow(FALSE);
		dlg4.ShowWindow(FALSE);
		dlg5.ShowWindow(FALSE);
		break;
	case 2:
		dlg3.ReadParameter();
		dlg1.ShowWindow(FALSE); 
		dlg2.ShowWindow(FALSE); 
		dlg3.ShowWindow(TRUE);
		dlg4.ShowWindow(FALSE);
		dlg5.ShowWindow(FALSE);
		dlg6.ShowWindow(FALSE);
		break; 
	case 3:
		dlg4.ReadParameter();
		dlg1.ShowWindow(FALSE); 
		dlg2.ShowWindow(FALSE); 
		dlg3.ShowWindow(FALSE);
		dlg4.ShowWindow(TRUE);
		dlg5.ShowWindow(FALSE);
		dlg6.ShowWindow(FALSE);
		break; 
	case 4:
		dlg1.ShowWindow(FALSE); 
		dlg2.ShowWindow(FALSE); 
		dlg3.ShowWindow(FALSE);
		dlg4.ShowWindow(FALSE);
		dlg5.ShowWindow(TRUE);
		dlg6.ShowWindow(FALSE);
		break; 
	case 5:
		dlg1.ShowWindow(FALSE); 
		dlg2.ShowWindow(FALSE); 
		dlg3.ShowWindow(FALSE);
		dlg4.ShowWindow(FALSE);
		dlg5.ShowWindow(FALSE);
		dlg6.ShowWindow(TRUE);
		break; 
	} 

	*pResult = 0;
}


void CEcpTextDlg::EditInPut(CString str)
{
	CString editstr;
	int len;
	str+="\r\n";
	GetDlgItemText(IDC_EDIT7,editstr);
	len=editstr.GetLength();
	m_edit7.SetSel(len, -1);     
	m_edit7.ReplaceSel(str);
	if (len>102400)
	{
		SetDlgItemText(IDC_EDIT7,"");
	}
}


void CEcpTextDlg::ElementEnable(DWORD IDC,BOOL flag)
{
  CWnd *Element;
  Element = GetDlgItem(IDC);     //��ȡ�ؼ�ָ�룬IDC_EDIT1Ϊ�ؼ�ID��
  Element->EnableWindow(flag);
}
  
void CEcpTextDlg::ElementShow(DWORD IDC,BOOL flag)
{
	CWnd *Element;
	Element = GetDlgItem(IDC);     //��ȡ�ؼ�ָ�룬IDC_EDIT1Ϊ�ؼ�ID��
	Element->ShowWindow(flag);
}


void CEcpTextDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON1,FALSE);
	if (MuitFlag)
		AfxMessageBox("��ֹͣ�࿨�ٹر�");
	if (hCom==INVALID_HANDLE_VALUE)
	{
		CString ComPort1;
		char ComPort[20]={0};
		GetDlgItemText(IDC_COMBO1,ComPort1);
		memcpy(ComPort,ComPort1,ComPort1.GetLength());

		if(ComOpenCom(&hCom,ComPort,GetDlgItemInt(IDC_EDIT3)))
		{
			ComStopReadTag(hCom);
			Sleep(200);
			ComStopReadTag(hCom);
			unsigned char recvbuf[10]={0};
			int flag;
			flag=ComReadVersion(hCom,recvbuf);
			if (flag==COM_COMMAND_SUCCESS)
			{
				EditInPut("�򿪴��ڳɹ�");
				CString str;
				str.Format("%d.%d",recvbuf[0],recvbuf[1]);
				SetWindowText("�����汾��V"+str);
				ElementEnable(IDC_BUTTON2,TRUE);
				ElementEnable(IDC_RADIO1,FALSE);
				ElementEnable(IDC_RADIO2,FALSE);
				ElementEnable(IDC_RADIO3,FALSE);

				m_tab1.ShowWindow(TRUE);
				return ;
			}
			else
			{
				ComCloseCom(&hCom);
				ElementEnable(IDC_BUTTON1,TRUE);
				AfxMessageBox("δ������");
				return ;
			}
			
		}
		else
			EditInPut("�򿪴���ʧ��");
	}
	ElementEnable(IDC_BUTTON1,TRUE);
}

void CEcpTextDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON2,FALSE);
	if (MuitFlag)
	{
		AfxMessageBox("��ֹͣ�࿨�ٹر�");
		ElementEnable(IDC_BUTTON2,TRUE);
		return;
	}
	
	if(hCom!=INVALID_HANDLE_VALUE)
	{
		m_tab1.ShowWindow(FALSE);
		ComResetReader(hCom);
		ComCloseCom(&hCom);
		EditInPut("�رմ��ڳɹ�");
		SetWindowText("�汾��δ֪");
		ElementEnable(IDC_BUTTON1,TRUE);
		ElementEnable(IDC_RADIO1,TRUE);
		ElementEnable(IDC_RADIO2,TRUE);
		ElementEnable(IDC_RADIO3,TRUE);
		return;
	}
	else
		EditInPut("�رմ���ʧ��");
	ElementEnable(IDC_BUTTON2,TRUE);
}

void CEcpTextDlg::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,1);
	ElementEnable(IDC_EDIT3,1);
	ElementEnable(IDC_BUTTON1,1);
//	ElementEnable(IDC_BUTTON2,1);
	
	
	ElementEnable(IDC_EDIT4,0);
	ElementEnable(IDC_EDIT5,0);
	ElementEnable(IDC_BUTTON3,0);
	ElementEnable(IDC_BUTTON4,0);
	ElementEnable(IDC_BUTTON8,FALSE);
	
	
	ElementEnable(IDC_EDIT6,FALSE);
	ElementEnable(IDC_BUTTON5,FALSE);
	ElementEnable(IDC_BUTTON6,FALSE);

}

void CEcpTextDlg::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,FALSE);
	ElementEnable(IDC_EDIT3,FALSE);
	ElementEnable(IDC_BUTTON1,FALSE);
	ElementEnable(IDC_BUTTON2,FALSE);
	
	
	ElementEnable(IDC_EDIT4,1);
	ElementEnable(IDC_EDIT5,1);
	ElementEnable(IDC_BUTTON3,1);
//	ElementEnable(IDC_BUTTON4,1);
	
	
	ElementEnable(IDC_EDIT6,FALSE);
	ElementEnable(IDC_BUTTON5,FALSE);
	ElementEnable(IDC_BUTTON6,FALSE);
}

void CEcpTextDlg::OnRadio3() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,FALSE);
	ElementEnable(IDC_EDIT3,FALSE);
	ElementEnable(IDC_BUTTON1,FALSE);
	ElementEnable(IDC_BUTTON2,FALSE);
	
	
	ElementEnable(IDC_EDIT4,FALSE);
	ElementEnable(IDC_EDIT5,FALSE);
	ElementEnable(IDC_BUTTON3,FALSE);
	ElementEnable(IDC_BUTTON4,FALSE);
	ElementEnable(IDC_BUTTON8,FALSE);
	
	
	ElementEnable(IDC_EDIT6,1);
	ElementEnable(IDC_BUTTON5,1);
//	ElementEnable(IDC_BUTTON6,1);
}

void CEcpTextDlg::OnButton7() 
{
	// TODO: Add your control notification handler code here
	SetDlgItemText(IDC_EDIT7,"");
	HeartCout=0;
	SetDlgItemText(IDC_STATIC_HEARD,"0");
}

//*********************************
//�ͻ���
//*********************************


void CEcpTextDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON3,FALSE);
	int flag;
	CString str;
	char clientIp[20]={0};
	int clientPort;

	GetDlgItemText(IDC_EDIT4,str);
	memcpy(clientIp,str,str.GetLength());
	clientPort=GetDlgItemInt(IDC_EDIT5);
	flag=SocketStartClient(&sockClient,clientIp,clientPort);
	if (flag==1)
	{
		SetTimer(1,30000,NULL);
		unsigned char recvbuf[10]={0};
		SocketStopReadTag(&sockClient);
		Sleep(200);
		flag=SocketReadVersion(&sockClient,recvbuf);
		if (flag==1)
		{
			EditInPut("��socket�ɹ�");
			str.Format("%d.%d",recvbuf[0],recvbuf[1]);
			SetWindowText("�����汾��V"+str);
			ElementEnable(IDC_BUTTON4,TRUE);
			ElementEnable(IDC_BUTTON8,TRUE);
			ElementEnable(IDC_RADIO1,FALSE);
			ElementEnable(IDC_RADIO2,FALSE);
			ElementEnable(IDC_RADIO3,FALSE);
			
			m_tab1.ShowWindow(TRUE);
			return ;
		}
		else
		{
			SocketCloseClient(&sockClient);
			str.Format("%d",flag);
			EditInPut(str);
		}
	}
	else
		AfxMessageBox("socket����ʧ��");

	ElementEnable(IDC_BUTTON3,TRUE);
}

void CEcpTextDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON4,FALSE);
	if (MuitFlag)
	{
		AfxMessageBox("��ֹͣ�࿨�ٹر�");
		ElementEnable(IDC_BUTTON4,TRUE);
		return;
	}
	if (sockClient!=SOCKET_ERROR||sockClient!=INVALID_SOCKET)
	{
		KillTimer(1);
		m_tab1.ShowWindow(FALSE);
		SocketCloseClient(&sockClient);
		EditInPut("�ر�socket�ɹ�");
		SetWindowText("�汾��δ֪");
		ElementEnable(IDC_BUTTON3,TRUE);
		ElementEnable(IDC_RADIO1,TRUE);
		ElementEnable(IDC_RADIO2,TRUE);
		ElementEnable(IDC_RADIO3,TRUE);
		ElementEnable(IDC_BUTTON8,FALSE);
		return;
	}
	else
		EditInPut("�رմ���ʧ��");
	ElementEnable(IDC_BUTTON4,TRUE);
}

void CEcpTextDlg::OnButton8() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON8,FALSE);
	if (MuitFlag)
	{
		AfxMessageBox("��ֹͣ�࿨�ٹر�");
		ElementEnable(IDC_BUTTON4,TRUE);
		return;
	}
	if (sockClient!=SOCKET_ERROR||sockClient!=INVALID_SOCKET)
	{
		SocketResetReader(&sockClient);
		OnButton4();
		return;
	}
	else
		EditInPut("��λ����ʧ��");
	ElementEnable(IDC_BUTTON8,TRUE);
}

//������
void CEcpTextDlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON5,FALSE);
	CString str;
	int SerPort=GetDlgItemInt(IDC_EDIT6);
	int flag=SocketStartServer(&sockClient,SerPort);
	if (flag==1)
	{
		SetTimer(1,30000,NULL);
		unsigned char recvbuf[10]={0};
		SocketStopReadTag(&sockClient);
		Sleep(200);
		flag=SocketReadVersion(&sockClient,recvbuf);
		if (flag==1)
		{
			EditInPut("��socket�ɹ�");
			str.Format("%d.%d",recvbuf[0],recvbuf[1]);
			SetWindowText("�����汾��V"+str);
			ElementEnable(IDC_BUTTON6,TRUE);
			ElementEnable(IDC_RADIO1,FALSE);
			ElementEnable(IDC_RADIO2,FALSE);
			ElementEnable(IDC_RADIO3,FALSE);
			
			m_tab1.ShowWindow(TRUE);
			return ;
		}
		else
		{
			SocketCloseServer(&sockClient);
			str.Format("%d",flag);
			EditInPut(str);
		}
	}
	else
	{
		str.Format("%d",flag);
		EditInPut(str);
		AfxMessageBox("socket����ʧ��");
	}
	
	ElementEnable(IDC_BUTTON5,TRUE);
}

void CEcpTextDlg::OnButton6() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON6,FALSE);
	if (MuitFlag)
	{
		AfxMessageBox("��ֹͣ�࿨�ٹر�");
		ElementEnable(IDC_BUTTON6,TRUE);
		return;
	}
	if (sockClient!=SOCKET_ERROR||sockClient!=INVALID_SOCKET)
	{
		KillTimer(1);
		m_tab1.ShowWindow(FALSE);
		SocketCloseServer(&sockClient);
		EditInPut("�ر�socket�ɹ�");
		SetWindowText("�汾��δ֪");
		ElementEnable(IDC_BUTTON5,TRUE);
		ElementEnable(IDC_RADIO1,TRUE);
		ElementEnable(IDC_RADIO2,TRUE);
		ElementEnable(IDC_RADIO3,TRUE);
		return;
	}
	else
		EditInPut("�رմ���ʧ��");
	ElementEnable(IDC_BUTTON6,TRUE);
}

void CEcpTextDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if (sockClient!=INVALID_SOCKET&&nIDEvent==1)
	{
		if (!SocketHeartbeatpacket(&sockClient))
			{
				KillTimer(1);
				AfxMessageBox("�����Ѿ��Ͽ�");
				return;
			}
		
		
		HeartCout++;
		CString str;
		str.Format("%d",HeartCout);
		SetDlgItemText(IDC_STATIC_HEARD,str);
		if (HeartCout>10000)
		{
			HeartCout=0;
		}
	}
	CDialog::OnTimer(nIDEvent);
}
