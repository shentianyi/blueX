// dlg1.cpp : implementation file
//

#include "stdafx.h"
#include "EcpText.h"
#include "dlg1.h"
#include "EcpTextDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Cdlg1 dialog
CEcpTextDlg *dlg1;

Cdlg1::Cdlg1(CWnd* pParent /*=NULL*/)
	: CDialog(Cdlg1::IDD, pParent)
{
	//{{AFX_DATA_INIT(Cdlg1)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Cdlg1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Cdlg1)
	DDX_Control(pDX, IDC_EDIT1, m_edit1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Cdlg1, CDialog)
	//{{AFX_MSG_MAP(Cdlg1)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cdlg1 message handlers

BOOL Cdlg1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Init1();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void Cdlg1::Init1()
{
	dlg1=(CEcpTextDlg*)(AfxGetApp()->m_pMainWnd);
//(CEcpTextDlg*)GetParent();
	OnRadio1();
	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
}

void Cdlg1::EditInPut(CString str)
{
	CString editstr;
	int len;
	str+="\r\n";
	GetDlgItemText(IDC_EDIT1,editstr);
	len=editstr.GetLength();
	m_edit1.SetSel(len, -1);     
	m_edit1.ReplaceSel(str);
	if (len>10240)
	{
		SetDlgItemText(IDC_EDIT1,"");
	}
}

void Cdlg1::ElementEnable(DWORD IDC,BOOL flag)
{
	CWnd *Element;
	Element = GetDlgItem(IDC);     //��ȡ�ؼ�ָ�룬IDC_EDIT1Ϊ�ؼ�ID��
	Element->EnableWindow(flag);
}

void Cdlg1::OnRadio1() 
{
	// TODO: Add your control notification handler code here
/*
	if (dlg1->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag=ComSetSingleParameter(dlg1->hCom,0x87,0);
		CString str;
		str.Format("%d",flag);
		EditInPut(str);
	
	}
	if (dlg1->sockClient!=INVALID_SOCKET)
	{
		int flag=SocketSetSingleParameter(&(dlg1->sockClient),0x87,0);
		CString str;
		str.Format("%d",flag);
		EditInPut(str);
	}
	*/
	ElementEnable(IDC_BUTTON2,FALSE);

}



void Cdlg1::OnRadio2() 
{
	// TODO: Add your control notification handler code here
/*
	if (dlg1->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag=ComSetSingleParameter(dlg1->hCom,0x80,1);
		CString str;
		str.Format("%d",flag);
		EditInPut(str);
	}

	if (dlg1->sockClient!=INVALID_SOCKET)
	{
		int flag=SocketSetSingleParameter(&(dlg1->sockClient),0x80,0);
		CString str;
		str.Format("%d",flag);
		EditInPut(str);
	}*/

}

void Cdlg1::OnButton1() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON1,FALSE);
	int radioflag=((CButton*)GetDlgItem(IDC_RADIO1))->GetCheck();
	int flag;
	if (dlg1->hCom!=INVALID_HANDLE_VALUE)
	{
			if (radioflag==1)//����
			{
				int cout1=10;
				unsigned char buf[20]={0};
				while(cout1--)
				{
					flag=ComTagIdentify(dlg1->hCom,4,buf);//����ǩʶ��
					if (flag==1)
					{
						break;
					}
				}
				
				if (flag==COM_COMMAND_SUCCESS)
				{
					CString str;
					str.Format("(����:%d) %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X",
						buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6],buf[7],buf[8],buf[9],buf[10],buf[11],buf[12]);
					EditInPut(str);
				}
				else
				{
					CString str;
					str.Format("%d",flag);
					EditInPut(str);	
				}
		}	
			
		else if (((CButton*)GetDlgItem(IDC_RADIO2))->GetCheck())
		//�࿨
		{
			
			if(ComStratReadMultiTag(dlg1->hCom))
			{
				ElementEnable(IDC_BUTTON2,TRUE);
				ElementEnable(IDC_BUTTON1,FALSE);
				MulitNub=0;
				SetTimer(1,200,NULL);
				dlg1->MuitFlag=TRUE;
				return ;
			}
		}
		else if (((CButton*)GetDlgItem(IDC_RADIO3))->GetCheck())
		{
			int cout1=10;
			unsigned char buf[20]={0};
			while(cout1--)
			{
				flag=ComTagIdentify(dlg1->hCom,1,buf);//6B����ǩʶ��
				if (flag==1)
				{
					break;
				}
			}
			
			if (flag==COM_COMMAND_SUCCESS)
			{
				CString str;
				str.Format("(����:%d) %02X %02X %02X %02X %02X %02X %02X %02X",
					buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6],buf[7],buf[8]);
				EditInPut(str);
			}
			else
			{
				CString str;
				str.Format("%d",flag);
				EditInPut(str);	
				}
		}
	}
	else if(dlg1->sockClient!=INVALID_SOCKET)
	{
		if (radioflag==1)//����
		{
		//	SocketSetOther(300);
			unsigned char buf[20]={0};
			int cout1=10;
			while(cout1--)
			{
				flag=SocketTagIdentify(&(dlg1->sockClient),4,buf);//����ǩʶ��
				if (flag==1)
				{
					break;
				}
			}
			
			if (flag==SOCKET_COMMAND_SUCCESS)
			{
				CString str;
				str.Format("(����:%d) %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X",
						buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6],buf[7],buf[8],buf[9],buf[10],buf[11],buf[12]);
				EditInPut(str);
			}
			else
			{
				CString str;
				str.Format("%d",flag);
				EditInPut(str);	
			}
		//	SocketSetOther(10);
			
		}
		else if (((CButton*)GetDlgItem(IDC_RADIO2))->GetCheck())
		{
		
			flag=SocketStartReadMultiTag(&(dlg1->sockClient));
			if(flag==1)
				{
					ElementEnable(IDC_BUTTON2,TRUE);
					ElementEnable(IDC_BUTTON1,FALSE);
					MulitNub=0;
					SetTimer(1,200,NULL);
					dlg1->MuitFlag=TRUE;
					return ;
				}
			else
			{
				CString str;
				str.Format("%d",flag);
				EditInPut(str);	
			}
		
		}
		else if (((CButton*)GetDlgItem(IDC_RADIO3))->GetCheck())
		{
			int cout1=10;
			unsigned char buf[20]={0};
			while(cout1--)
			{
				flag=SocketTagIdentify(&(dlg1->sockClient),1,buf);//6B����ǩʶ��
				if (flag==1)
				{
					break;
				}
			}
			
			if (flag==COM_COMMAND_SUCCESS)
			{
				CString str;
				str.Format("(����:%d) %02X %02X %02X %02X %02X %02X %02X %02X",
					buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6],buf[7],buf[8]);
				EditInPut(str);
			}
			else
			{
				CString str;
				str.Format("%d",flag);
				EditInPut(str);	
			}
		}
	}
	ElementEnable(IDC_BUTTON1,TRUE);
}

void Cdlg1::ComReadMuitTagBuf()
{
	unsigned char buf[4096]={0};
	unsigned char cout[2]={0};
	BOOL flag=ComGetMultiTagBuf(cout,buf);
	int len=cout[0];
	if (len>0)
	{
		for (int i=0;i<len;i++)
		{
			MulitNub++;
			
			CString str;
			str.Format("NO %d: %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X (����%d)",MulitNub,
		buf[i*13+0],buf[i*13+1],buf[i*13+2],buf[i*13+3],buf[i*13+4],buf[i*13+5],buf[i*13+6]
		,buf[i*13+7],buf[i*13+8],buf[i*13+9],buf[i*13+10],buf[i*13+11],buf[i*13+12]);
		EditInPut(str);
		if (MulitNub>60000)
				MulitNub=0;
		}
		
		
	}
}

void Cdlg1::SocketReadMuitTagBuf()
{
	unsigned char buf[4096]={0};
	unsigned char mulitbuf[100]={0};
	char bufdata[100]={0};
	unsigned char cout[2]={0};
	BOOL flag=SocketGetMultiTagBuf(cout,buf);
	int len=cout[0];
	if (len>0)
	{
		if (len>0)
		{
			for (int i=0;i<len;i++)
			{
				MulitNub++;
				
				CString str;
				str.Format("NO %d: %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X (����%d)",MulitNub,
					buf[i*13+0],buf[i*13+1],buf[i*13+2],buf[i*13+3],buf[i*13+4],buf[i*13+5],buf[i*13+6]
					,buf[i*13+7],buf[i*13+8],buf[i*13+9],buf[i*13+10],buf[i*13+11],buf[i*13+12]);
				EditInPut(str);
				if (MulitNub>60000)
					MulitNub=0;
			}
			
			
	}
		
		
	}
}


void Cdlg1::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if (nIDEvent==1)
	{
		if (dlg1->hCom!=INVALID_HANDLE_VALUE)
		{
			ComReadMuitTagBuf();
		}
		if (dlg1->sockClient!=INVALID_SOCKET)
		{
			SocketReadMuitTagBuf();
		}
		
	}
	
	CDialog::OnTimer(nIDEvent);
}

void Cdlg1::OnButton2() 
{
	// TODO: Add your control notification handler code here
	if (dlg1->hCom!=INVALID_HANDLE_VALUE)
	{
		ComStopReadMultiTag(dlg1->hCom);
		dlg1->MuitFlag=FALSE;
		KillTimer(1);
		dlg1->EditInPut("ֹͣ���࿨�ɹ�");
		ElementEnable(IDC_BUTTON1,TRUE);
		ElementEnable(IDC_BUTTON2,FALSE);
	}
	else if (dlg1->sockClient!=INVALID_SOCKET)
	{
		SocketStopReadMultiTag(&(dlg1->sockClient));
		dlg1->MuitFlag=FALSE;
		KillTimer(1);
		dlg1->EditInPut("ֹͣ���࿨�ɹ�");
		ElementEnable(IDC_BUTTON1,TRUE);
		ElementEnable(IDC_BUTTON2,FALSE);
	}
}

void Cdlg1::OnButton3() 
{
	// TODO: Add your control notification handler code here
	SetDlgItemText(IDC_EDIT1,"");
//	dlg1->SetDlgItemText(IDC_EDIT7,"");
}
