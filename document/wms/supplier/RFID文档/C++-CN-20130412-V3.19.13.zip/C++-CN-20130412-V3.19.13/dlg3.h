#if !defined(AFX_DLG3_H__1BF413DB_2F8D_4705_880C_11B9B0DF3371__INCLUDED_)
#define AFX_DLG3_H__1BF413DB_2F8D_4705_880C_11B9B0DF3371__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlg3.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Cdlg3 dialog

class Cdlg3 : public CDialog
{
// Construction
public:
	Cdlg3(CWnd* pParent = NULL);   // standard constructor

public:
	void ElementEnable(DWORD IDC,BOOL flag);
	void Init();
	void ReadParameter();
	void SetParameter();
public:
	int RadioFlag;
// Dialog Data
	//{{AFX_DATA(Cdlg3)
	enum { IDD = IDD_DIALOG3 };
	CComboBox	m_listbox4;
	CComboBox	m_listbox3;
	CComboBox	m_listbox2;
	CComboBox	m_listbox1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Cdlg3)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Cdlg3)
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	afx_msg void OnCheck1();
	afx_msg void OnButton2();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadio3();
	afx_msg void OnSelchangeCombo2();
	afx_msg void OnButton3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG3_H__1BF413DB_2F8D_4705_880C_11B9B0DF3371__INCLUDED_)
