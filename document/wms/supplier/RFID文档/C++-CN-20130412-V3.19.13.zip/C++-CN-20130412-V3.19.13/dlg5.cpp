// dlg5.cpp : implementation file
//

#include "stdafx.h"
#include "EcpText.h"
#include "dlg5.h"
#include "EcpTextDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Cdlg5 dialog

CEcpTextDlg *dlg5;

Cdlg5::Cdlg5(CWnd* pParent /*=NULL*/)
	: CDialog(Cdlg5::IDD, pParent)
{
	//{{AFX_DATA_INIT(Cdlg5)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Cdlg5::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Cdlg5)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Cdlg5, CDialog)
	//{{AFX_MSG_MAP(Cdlg5)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_BN_CLICKED(IDC_BUTTON11, OnButton11)
	ON_BN_CLICKED(IDC_BUTTON12, OnButton12)
	ON_BN_CLICKED(IDC_BUTTON13, OnButton13)
	ON_BN_CLICKED(IDC_BUTTON14, OnButton14)
	ON_BN_CLICKED(IDC_BUTTON15, OnButton15)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cdlg5 message handlers
BOOL Cdlg5::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	DlgInit();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void Cdlg5::DlgInit()
{
	dlg5=(CEcpTextDlg*)(AfxGetApp()->m_pMainWnd);
}

void Cdlg5::OnButton1() 
{
	// TODO: Add your control notification handler code here
	if (dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		CString str;
		int i;
		GetDlgItemText(IDC_EDIT1,str);
		int cout=strlen(str);
		if(cout!=6)
		{
			dlg5->EditInPut("������1-9����A-F��6λ����");
			return;
		}
		for (i=0;i<6;i++)
		{
			if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
			{
				;
			}
			else
			{
				
				dlg5->EditInPut("������1-9����A-F��6λ����");
				return;
			}
		}
		unsigned char temp1,temp2;
		unsigned char senbuff[3]={0};
		
		for (i=0;i<3;i++)
		{
			temp1=str[i*2];
			temp2=str[i*2+1];
			senbuff[i]=CharToHex(temp1)*16+CharToHex(temp2);
		}
		
		
		int flag=ComOperationPassWorld(dlg5->hCom,1,senbuff);
		if (flag==1)
		{
			
			dlg5->EditInPut("��½�ɹ�");
		}
		else
			dlg5->EditInPut("��½ʧ��");
	}


//*****************************************************************

	if (dlg5->sockClient!=INVALID_SOCKET)
	{
		CString str;
		int i;
		GetDlgItemText(IDC_EDIT1,str);
		int cout=strlen(str);
		if(cout!=6)
		{
			dlg5->EditInPut("������1-9����A-F��6λ����");
			return;
		}
		for (i=0;i<6;i++)
		{
			if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
			{
				;
			}
			else
			{
				
				dlg5->EditInPut("������1-9����A-F��6λ����");
				return;
			}
		}
		unsigned char temp1,temp2;
		unsigned char senbuff[3]={0};
		
		for (i=0;i<3;i++)
		{
			temp1=str[i*2];
			temp2=str[i*2+1];
			senbuff[i]=CharToHex(temp1)*16+CharToHex(temp2);
		}
		
		
		int flag=SocketOperationPassWorld(&(dlg5->sockClient),1,senbuff);
		if (flag==1)
		{
			
			dlg5->EditInPut("��½�ɹ�");
		}
		else
			dlg5->EditInPut("��½ʧ��");
	}
}




void Cdlg5::OnButton2() 
{
	// TODO: Add your control notification handler code here
	if (dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag=1;
		int i;
		CString str,str1;
		GetDlgItemText(IDC_EDIT2,str);
		GetDlgItemText(IDC_EDIT3,str1);
		if (str!=str1)
		{
			dlg5->EditInPut("�������벻һ��");
			return;
		}
		int cout=strlen(str);
		
		if(cout!=6)
		{
			dlg5->EditInPut("������1-9����A-F��6λ����");
			return;
		}

		for (i=0;i<6;i++)
		{
			if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
			{
				;
			}
			else
			{
				
				dlg5->EditInPut("������1-9����A-F��6λ����");
				return;
			}
		}

		unsigned char temp1,temp2;
		unsigned char senbuff[3]={0};
		
		for (i=0;i<3;i++)
		{
			temp1=str[i*2];
			temp2=str[i*2+1];
			senbuff[i]=CharToHex(temp1)*16+CharToHex(temp2);
		}
		
		
		flag=ComOperationPassWorld(dlg5->hCom,2,senbuff);
		if (flag==1)
		{
			dlg5->EditInPut("�޸ĵ�½����ɹ�");
		}
		else
			dlg5->EditInPut("�޸ĵ�½����ʧ��");
	}

//**************************************************************
	if (dlg5->sockClient!=INVALID_SOCKET)
	{
		int flag=1;
		int i;
		CString str,str1;
		GetDlgItemText(IDC_EDIT2,str);
		GetDlgItemText(IDC_EDIT3,str1);
		if (str!=str1)
		{
			dlg5->EditInPut("�������벻һ��");
			return;
		}
		int cout=strlen(str);
		
		if(cout!=6)
		{
			dlg5->EditInPut("������1-9����A-F��6λ����");
			return;
		}
		
		for (i=0;i<6;i++)
		{
			if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
			{
				;
			}
			else
			{
				
				dlg5->EditInPut("������1-9����A-F��6λ����");
				return;
			}
		}
		
		unsigned char temp1,temp2;
		unsigned char senbuff[3]={0};
		
		for (i=0;i<3;i++)
		{
			temp1=str[i*2];
			temp2=str[i*2+1];
			senbuff[i]=CharToHex(temp1)*16+CharToHex(temp2);
		}
		
		
		flag=SocketOperationPassWorld(&(dlg5->sockClient),2,senbuff);
		if (flag==1)
		{
			dlg5->EditInPut("�޸ĵ�½����ɹ�");
		}
		else
			dlg5->EditInPut("�޸ĵ�½����ʧ��");
	}
}

void Cdlg5::OnButton3() 
{
	// TODO: Add your control notification handler code here
	if (dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag=1;
		int i;
		CString str,str1;
		GetDlgItemText(IDC_EDIT2,str);
		GetDlgItemText(IDC_EDIT3,str1);
		
		if (str!=str1)
		{
			dlg5->EditInPut("�������벻һ��");
			return;
		}
		
		int cout=strlen(str);
		if(cout!=6)
		{
			dlg5->EditInPut("������1-9����A-F��6λ����");
			return;
		}
		
		for (i=0;i<6;i++)
		{
			if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
			{
				;
			}
			else
			{
				
				dlg5->EditInPut("������1-9����A-F��6λ����");
				return;
			}
		}

		unsigned char temp1,temp2;
		unsigned char senbuff[3]={0};
		
		for (i=0;i<3;i++)
		{
			temp1=str[i*2];
			temp2=str[i*2+1];
			senbuff[i]=CharToHex(temp1)*16+CharToHex(temp2);
		}
		
		
		flag=ComOperationPassWorld(dlg5->hCom,3,senbuff);
		if (flag==1)
		{
			dlg5->EditInPut("�޸Ķ�ȡ����ɹ�");
		}
		else
			dlg5->EditInPut("�޸Ķ�ȡ����ʧ��");
	}

	//*****************************************************
	if (dlg5->sockClient!=INVALID_SOCKET)
	{
		int flag=1;
		int i;
		CString str,str1;
		GetDlgItemText(IDC_EDIT2,str);
		GetDlgItemText(IDC_EDIT3,str1);
		
		if (str!=str1)
		{
			dlg5->EditInPut("�������벻һ��");
			return;
		}
		
		int cout=strlen(str);
		if(cout!=6)
		{
			dlg5->EditInPut("������1-9����A-F��6λ����");
			return;
		}
		
		for (i=0;i<6;i++)
		{
			if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
			{
				;
			}
			else
			{
				
				dlg5->EditInPut("������1-9����A-F��6λ����");
				return;
			}
		}
		
		unsigned char temp1,temp2;
		unsigned char senbuff[3]={0};
		
		for (i=0;i<3;i++)
		{
			temp1=str[i*2];
			temp2=str[i*2+1];
			senbuff[i]=CharToHex(temp1)*16+CharToHex(temp2);
		}
		
		
		flag=SocketOperationPassWorld(&(dlg5->sockClient),3,senbuff);
		if (flag==1)
		{
			dlg5->EditInPut("�޸Ķ�ȡ����ɹ�");
		}
		else
			dlg5->EditInPut("�޸Ķ�ȡ����ʧ��");
	}
}

void Cdlg5::OnButton4() 
{
	// TODO: Add your control notification handler code here
	if (dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag;
		unsigned char receive[20]={0};
		flag=ComCheckPassWorld(dlg5->hCom,2,receive);
		if(flag==1)
		{
			CString str;
			str.Format("%02x%02x%02x",receive[0],receive[1],receive[2]);
			str="��ȡ����½����! ����Ϊ:"+str;
			dlg5->EditInPut(str);
		}
		else
			dlg5->EditInPut("��ȡ��½��½ʧ��");
	}

//***************************************************************

	if (dlg5->sockClient!=INVALID_SOCKET)
	{
		int flag;
		unsigned char receive[20]={0};
		flag=SocketCheckPassWorld(&(dlg5->sockClient),2,receive);
		if(flag==1)
		{
			CString str;
			str.Format("%02x%02x%02x",receive[0],receive[1],receive[2]);
			str="��ȡ����½����! ����Ϊ:"+str;
			dlg5->EditInPut(str);
		}
		else
			dlg5->EditInPut("��ȡ��½��½ʧ��");
	}
}

void Cdlg5::OnButton5() 
{
	// TODO: Add your control notification handler code here
	if (dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag;
		unsigned char receive[20]={0};
		flag=ComCheckPassWorld(dlg5->hCom,1,receive);
		if(flag==1)
		{
			CString str;
			str.Format("%02x%02x%02x",receive[0],receive[1],receive[2]);
			str="��ȡ����ȡ����! ����Ϊ:"+str;
			dlg5->EditInPut(str);
		}
		else
			dlg5->EditInPut("��ȡ��ѯ��ȡʧ��");
	}

	//*****************************************************

	if (dlg5->sockClient!=INVALID_SOCKET)
	{
		int flag;
		unsigned char receive[20]={0};
		flag=SocketCheckPassWorld(&(dlg5->sockClient),1,receive);
		if(flag==1)
		{
			CString str;
			str.Format("%02x%02x%02x",receive[0],receive[1],receive[2]);
			str="��ȡ����ȡ����! ����Ϊ:"+str;
			dlg5->EditInPut(str);
		}
		else
			dlg5->EditInPut("��ȡ��ѯ��ȡʧ��");
	}
}

void Cdlg5::OnButton6() 
{
	if (dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char IP[5]={0};
		IP[0]=GetDlgItemInt(IDC_EDIT6);
		IP[1]=GetDlgItemInt(IDC_EDIT8);
		IP[2]=GetDlgItemInt(IDC_EDIT9);
		IP[3]=GetDlgItemInt(IDC_EDIT10);
		int Port=GetDlgItemInt(IDC_EDIT7);
		int flag=ComSetIpPort(dlg5->hCom,IP,Port);
		if(flag==1)
			dlg5->EditInPut("IP�Ͷ˿����óɹ�");
		else
			dlg5->EditInPut("IP�Ͷ˿�����ʧ��");
	}


	//*****************************************************


	if (dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char IP[5]={0};
		IP[0]=GetDlgItemInt(IDC_EDIT6);
		IP[1]=GetDlgItemInt(IDC_EDIT8);
		IP[2]=GetDlgItemInt(IDC_EDIT9);
		IP[3]=GetDlgItemInt(IDC_EDIT10);
		int Port=GetDlgItemInt(IDC_EDIT7);
		int flag=SocketSetIpPort(&(dlg5->sockClient),IP,Port);
		if(flag==1)
			dlg5->EditInPut("IP�Ͷ˿����óɹ�");
		else
			dlg5->EditInPut("IP�Ͷ˿�����ʧ��");
	}
}

void Cdlg5::OnButton7() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char Date[5]={0};
		unsigned char Time[5]={0};
		int value=GetDlgItemInt(IDC_EDIT11);
		Date[0]=value/256;
		Date[1]=value%256;
		Date[2]=GetDlgItemInt(IDC_EDIT12);
		Date[3]=GetDlgItemInt(IDC_EDIT13);
		Date[4]=4;

		Time[0]=GetDlgItemInt(IDC_EDIT14);
		Time[1]=GetDlgItemInt(IDC_EDIT15);
		Time[2]=GetDlgItemInt(IDC_EDIT16);

		int flag1,flag2;
		flag1=ComSetData(dlg5->hCom,Date);
		if(flag1==1)
		{
			flag2=ComSetTime(dlg5->hCom,Time);
			if(flag2==1)
				dlg5->EditInPut("ʱ����������óɹ�");
			else
				dlg5->EditInPut("ʱ������ʧ��");
		}
		else
			dlg5->EditInPut("��������ʧ��");


	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char Date[5]={0};
		unsigned char Time[5]={0};
		int value=GetDlgItemInt(IDC_EDIT11);
		Date[0]=value/256;
		Date[1]=value%256;
		Date[2]=GetDlgItemInt(IDC_EDIT12);
		Date[3]=GetDlgItemInt(IDC_EDIT13);
		Date[4]=4;

		Time[0]=GetDlgItemInt(IDC_EDIT14);
		Time[1]=GetDlgItemInt(IDC_EDIT15);
		Time[2]=GetDlgItemInt(IDC_EDIT16);

		int flag1,flag2;
		flag1=SocketSetData(&(dlg5->sockClient),Date);
		if(flag1==1)
		{
			flag2=SocketSetTime(&(dlg5->sockClient),Time);
			if(flag2==1)
				dlg5->EditInPut("ʱ����������óɹ�");
			else
				dlg5->EditInPut("ʱ������ʧ��");
		}
		else
			dlg5->EditInPut("��������ʧ��");
	}
}

void Cdlg5::OnButton8() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char MACAddress[9]={0};
		MACAddress[0]=GetDlgItemInt(IDC_EDIT17);
		MACAddress[1]=GetDlgItemInt(IDC_EDIT18);
		MACAddress[2]=GetDlgItemInt(IDC_EDIT19);
		MACAddress[3]=GetDlgItemInt(IDC_EDIT20);
		MACAddress[4]=GetDlgItemInt(IDC_EDIT21);
		MACAddress[5]=GetDlgItemInt(IDC_EDIT22);
		MACAddress[6]=GetDlgItemInt(IDC_EDIT23);
		MACAddress[7]=GetDlgItemInt(IDC_EDIT24);

		int flag=ComSetMAC(dlg5->hCom,MACAddress);
		if(flag==1)
		{
			dlg5->EditInPut("MAC��ַ���óɹ�");
		}
		else
			dlg5->EditInPut("MAC��ַ����ʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char MACAddress[9]={0};
		MACAddress[0]=GetDlgItemInt(IDC_EDIT17);
		MACAddress[1]=GetDlgItemInt(IDC_EDIT18);
		MACAddress[2]=GetDlgItemInt(IDC_EDIT19);
		MACAddress[3]=GetDlgItemInt(IDC_EDIT20);
		MACAddress[4]=GetDlgItemInt(IDC_EDIT21);
		MACAddress[5]=GetDlgItemInt(IDC_EDIT22);
		MACAddress[6]=GetDlgItemInt(IDC_EDIT23);
		MACAddress[7]=GetDlgItemInt(IDC_EDIT24);

		int flag=SocketSetMAC(&(dlg5->sockClient),MACAddress);
		if(flag==1)
		{
			dlg5->EditInPut("MAC��ַ���óɹ�");
		}
		else
			dlg5->EditInPut("MAC��ַ����ʧ��");
	}
}

void Cdlg5::OnButton9() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag=ComSetHDCP(dlg5->hCom);
		if(flag==1)
			dlg5->EditInPut("DHCP��Ч���óɹ�");
		else
			dlg5->EditInPut("DHCP��Ч����ʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		int flag=ComSetHDCP(&(dlg5->sockClient));
		if(flag==1)
			dlg5->EditInPut("DHCP��Ч���óɹ�");
		else
			dlg5->EditInPut("DHCP��Ч����ʧ��");
	}
}

void Cdlg5::OnButton10() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char ID;
		unsigned char Relay;
		unsigned char mtime;
		ID=GetDlgItemInt(IDC_EDIT25);
		Relay=GetDlgItemInt(IDC_EDIT26);
		mtime=GetDlgItemInt(IDC_EDIT27);

		int flag=ComSetRelay(dlg5->hCom,ID,Relay,mtime);
		if(flag==1)
		{
			dlg5->EditInPut("�̵����������óɹ�");
		}
		else
			dlg5->EditInPut("�̵�����������ʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char ID;
		unsigned char Relay;
		unsigned char mtime;
		ID=GetDlgItemInt(IDC_EDIT25);
		Relay=GetDlgItemInt(IDC_EDIT26);
		mtime=GetDlgItemInt(IDC_EDIT27);

		int flag=SocketSetRelay(&(dlg5->sockClient),ID,Relay,mtime);
		if(flag==1)
		{
			dlg5->EditInPut("�̵����������óɹ�");
		}
		else
			dlg5->EditInPut("�̵�����������ʧ��");
	}
}

void Cdlg5::OnButton11() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char RecvBuf[3]={0};
		int flag=ComIOPortState(dlg5->hCom,RecvBuf);
		if(flag==1)
		{
			CString str;
			str.Format("%d",RecvBuf[0]);
			SetDlgItemText(IDC_EDIT28,str);
		}
		else
			dlg5->EditInPut("GPIO�ڶ�ȡʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char RecvBuf[3]={0};
		int flag=SocketIOPortState(&(dlg5->sockClient),RecvBuf);
		if(flag==1)
		{
			CString str;
			str.Format("%d",RecvBuf[0]);
			SetDlgItemText(IDC_EDIT28,str);
		}
		else
			dlg5->EditInPut("GPIO�ڶ�ȡʧ��");
	}
}

void Cdlg5::OnButton12() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char RecvBuf[10]={0};
		int flag=ComQueryArray(dlg5->hCom,RecvBuf);
		if(flag==1)
		{
			int value=RecvBuf[0]*256+RecvBuf[1];
			CString str;
			str.Format("%d",value);
			SetDlgItemText(IDC_EDIT29,str);
		}
		else
			dlg5->EditInPut("��ȡ�洢����ʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char RecvBuf[10]={0};
		int flag=SocketQueryArray(&(dlg5->sockClient),RecvBuf);
		if(flag==1)
		{
			int value=RecvBuf[0]*256+RecvBuf[1];
			CString str;
			str.Format("%d",value);
			SetDlgItemText(IDC_EDIT29,str);
		}
		else
			dlg5->EditInPut("��ȡ�洢����ʧ��");
	}
}

void Cdlg5::OnButton13() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char RecvBuf[100]={0};
		int flag=ComActiveResponse(dlg5->hCom,RecvBuf);
		if(flag==1)
		{
			dlg5->EditInPut("Ӧ��ɹ�");
		}
		else
			dlg5->EditInPut("Ӧ��ʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char RecvBuf[100]={0};
		int flag=SocketActiveResponse(&(dlg5->sockClient),RecvBuf);
		if(flag==1)
		{
			dlg5->EditInPut("Ӧ��ɹ�");
		}
		else
			dlg5->EditInPut("Ӧ��ʧ��");
	}
}

void Cdlg5::OnButton14() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char buf[1024]={0};
		int count;
		int flag=ComDataAcquisition(dlg5->hCom,count,buf);
		if(flag==1)
		{
			for(int i=0;i<count;i++)
			{
				CString str;
				str.Format("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X",buf[i*19+0],buf[i*19+1],buf[i*19+2],buf[i*19+3],buf[i*19+4],buf[i*19+5],buf[i*19+6],buf[i*19+7],buf[i*19+8],buf[i*19+9],buf[i*19+10],buf[i*19+11],buf[i*19+12],buf[i*19+13],buf[i*19+14],buf[i*19+15],buf[i*19+16],buf[i*19+17],buf[i*19+18]);
				str+="\r\n";
				SetDlgItemText(IDC_EDIT30,str);
			}
		}
		else
			dlg5->EditInPut("���ݲɼ�ʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char buf[1024]={0};
		int count;
		int flag=SocketDataAcquisition(&(dlg5->sockClient),count,buf);
		if(flag==1)
		{
			for(int i=0;i<count;i++)
			{
				CString str;
				str.Format("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X",buf[i*19+0],buf[i*19+1],buf[i*19+2],buf[i*19+3],buf[i*19+4],buf[i*19+5],buf[i*19+6],buf[i*19+7],buf[i*19+8],buf[i*19+9],buf[i*19+10],buf[i*19+11],buf[i*19+12],buf[i*19+13],buf[i*19+14],buf[i*19+15],buf[i*19+16],buf[i*19+17],buf[i*19+18]);
				str+="\r\n";
				SetDlgItemText(IDC_EDIT30,str);
			}
		}
		else
			dlg5->EditInPut("���ݲɼ�ʧ��");
	}
}

void Cdlg5::OnButton15() 
{
	if(dlg5->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char RecvBuf[20]={0};
		int flag=ComReadTime(dlg5->hCom,RecvBuf);
		if(flag==1)
		{
			CString str;
			int value=RecvBuf[0]*256+RecvBuf[1];
			str.Format("%d",value);
			SetDlgItemText(IDC_EDIT11,str);

			str.Format("%d",RecvBuf[2]);
			SetDlgItemText(IDC_EDIT12,str);

			str.Format("%d",RecvBuf[3]);
			SetDlgItemText(IDC_EDIT13,str);

			str.Format("%d",RecvBuf[5]);
			SetDlgItemText(IDC_EDIT14,str);

			str.Format("%d",RecvBuf[6]);
			SetDlgItemText(IDC_EDIT15,str);

			str.Format("%d",RecvBuf[7]);
			SetDlgItemText(IDC_EDIT16,str);

		}
		else
			dlg5->EditInPut("��ȡʱ�������ʧ��");
	}

	//*****************************************************

	if(dlg5->sockClient!=INVALID_SOCKET)
	{
		unsigned char RecvBuf[20]={0};
		int flag=SocketReadTime(&(dlg5->sockClient),RecvBuf);
		if(flag==1)
		{
			CString str;
			int value=RecvBuf[0]*256+RecvBuf[1];
			str.Format("%d",value);
			SetDlgItemText(IDC_EDIT11,str);

			str.Format("%d",RecvBuf[2]);
			SetDlgItemText(IDC_EDIT12,str);

			str.Format("%d",RecvBuf[3]);
			SetDlgItemText(IDC_EDIT13,str);

			str.Format("%d",RecvBuf[5]);
			SetDlgItemText(IDC_EDIT14,str);

			str.Format("%d",RecvBuf[6]);
			SetDlgItemText(IDC_EDIT15,str);

			str.Format("%d",RecvBuf[7]);
			SetDlgItemText(IDC_EDIT16,str);

		}
		else
			dlg5->EditInPut("��ȡʱ�������ʧ��");
	}

}