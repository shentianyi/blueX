// dlg6.cpp : implementation file
//

#include "stdafx.h"
#include "EcpText.h"
#include "dlg6.h"
#include "EcpTextDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Cdlg6 dialog
CEcpTextDlg *dlg6;

Cdlg6::Cdlg6(CWnd* pParent /*=NULL*/)
	: CDialog(Cdlg6::IDD, pParent)
{
	//{{AFX_DATA_INIT(Cdlg6)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Cdlg6::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Cdlg6)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Cdlg6, CDialog)
	//{{AFX_MSG_MAP(Cdlg6)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cdlg6 message handlers
BOOL Cdlg6::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Init6();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void Cdlg6::Init6()
{
	dlg6=(CEcpTextDlg*)(AfxGetApp()->m_pMainWnd);
	SetDlgItemText(IDC_EDIT1,"19");
	SetDlgItemText(IDC_EDIT2,"1");

	SetDlgItemText(IDC_EDIT4,"19");
	SetDlgItemText(IDC_EDIT5,"1");
	SetDlgItemText(IDC_EDIT6,"ff");
	GetDlgItem(IDC_EDIT5)->EnableWindow(FALSE);

	SetDlgItemText(IDC_EDIT7,"13");
}

void Cdlg6::OnButton1() 
{
	// TODO: Add your control notification handler code here
	char Address=GetDlgItemInt(IDC_EDIT1);
	int Length=GetDlgItemInt(IDC_EDIT2);
	unsigned char buf[200]={0};
	CString str,str2;
		int flag;
	if (dlg6->hCom!=INVALID_HANDLE_VALUE)
	{
		
	flag=ComReadTag6BContent(dlg6->hCom,Address,Length,buf);
	if (flag==1)
	{
		str+="ID��";
		for (int i=0;i<8;i++)
		{
			str2.Format("%02X ",buf[i]);
			str+=str2;
		}
		str+="\r\n";
		str2="";
		str+="���ݣ�";
		for (i=0;i<Length;i++)
		{
			str2.Format("%02X ",buf[8+i]);
			str+=str2;
		}
		
		SetDlgItemText(IDC_EDIT3,str);
	}
	else
	{
		CString str;
		str.Format("%d",flag);
		SetDlgItemText(IDC_EDIT3,str);	
		
	}
	}

	if (dlg6->sockClient!=INVALID_SOCKET)
	{
	
		flag=SocketRead6BTagContent(&(dlg6->sockClient),Address,Length,buf);
		if (flag==1)
		{
			str+="ID��";
		for (int i=0;i<8;i++)
		{
			str2.Format("%02X ",buf[i]);
			str+=str2;
		}
		str+="\r\n";
		str2="";
		str+="���ݣ�";
		for (i=0;i<Length;i++)
		{
			str2.Format("%02X ",buf[8+i]);
			str+=str2;
		}
			
			SetDlgItemText(IDC_EDIT3,str);
		}
		else
		{
			CString str;
			str.Format("%d",flag);
			SetDlgItemText(IDC_EDIT3,str);	
			
		}
	}
}

void Cdlg6::OnButton2() 
{
	// TODO: Add your control notification handler code here
	CString str;
	int i;
	int Address=GetDlgItemInt(IDC_EDIT4);
	int Length=GetDlgItemInt(IDC_EDIT5);
	GetDlgItemText(IDC_EDIT6,str);
	int cout=strlen(str);
	if(cout!=Length*2)
	{
		dlg6->EditInPut("����ĳ��Ȳ���");
		return;
	}
	for (i=0;i<cout;i++)
	{
		if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
		{
			;
		}
		else
		{
			
			dlg6->EditInPut("������1-9����A-F��6λ����");
			return;
		}
	}
	unsigned char temp1,temp2;
	unsigned char senbuff[3]={0};
	
	for (i=0;i<Length;i++)
	{
		temp1=str[i*2];
		temp2=str[i*2+1];
		senbuff[i]=CharToHex(temp1)*16+CharToHex(temp2);
	}

	int flag;
	if (dlg6->hCom!=INVALID_HANDLE_VALUE)
	{
		flag=ComTag6BWriteWord(dlg6->hCom,Address,Length,senbuff);
		if (flag==1)
		{
			dlg6->EditInPut("д���ǩ�ɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg6->EditInPut(str);
		}
	}
	if (dlg6->sockClient!=INVALID_SOCKET)
	{
		flag=SocketTag6BWriteWord(&(dlg6->sockClient),Address,Length,senbuff);
		if (flag==1)
		{
			dlg6->EditInPut("д���ǩ�ɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg6->EditInPut(str);
		}
	}
}

void Cdlg6::OnButton3() 
{
	// TODO: Add your control notification handler code here
	CString str;
	int i;
	GetDlgItemText(IDC_EDIT7,str);
	int cout=strlen(str);
	char Address=0;
	if(cout!=2)
	{
		dlg6->EditInPut("��ַ����");
		return;
	}
	for (i=0;i<cout;i++)
	{
		if ((str[i]>='0'&&str[i]<='9')||(str[i]>='A'&&str[i]<='F')||(str[i]>='a'&&str[i]<='f'))
		{
			;
		}
		else
		{
			
			dlg6->EditInPut("������1-9����A-F��6λ����");
			return;
		}
	}
	unsigned char temp1,temp2;
		temp1=str[0];
		temp2=str[1];
		Address=CharToHex(temp1)*16+CharToHex(temp2);

	if (Address<0x13)
	{
		dlg6->EditInPut("��ַҪ����0x13");
		return ;
	}
	int flag=ComTag6BLock(dlg6->hCom,Address);
	if (flag==1)
	{
		dlg6->EditInPut("�����ɹ�");
	}
	else
	{
		str.Format("%d",flag);
		dlg6->EditInPut(str);
	}
}

void Cdlg6::OnButton4()
{
	if(dlg6->hCom!=INVALID_HANDLE_VALUE)
	{
		unsigned char ID[12]={0};
		CString str;
		GetDlgItemText(IDC_EDIT8,str);
		int len=strlen(str)/2;
		if(len==12)
		{
			for(int i=0;i<len;i++)
			{
				ID[i]=CharToHex((uchar)str[i*2])*16+CharToHex((uchar)str[i*2+1]);
			}
			int flag=ComLoadAuthoId(dlg6->hCom,ID);
			if(flag==1)
			{
				dlg6->EditInPut("��ȨID����ɹ�");
			}
			else
				dlg6->EditInPut("��ȨID����ʧ��");
		}
		else
			dlg6->EditInPut("�����ID������");
	}

	if (dlg6->sockClient!=INVALID_SOCKET)
	{
		unsigned char ID[12]={0};
		CString str;
		GetDlgItemText(IDC_EDIT8,str);
		int len=strlen(str)/2;
		if(len==12)
		{
			for(int i=0;i<len;i++)
			{
				ID[i]=CharToHex((uchar)str[i*2])*16+CharToHex((uchar)str[i*2+1]);
			}
			int flag=SocketLoadAuthoId(&(dlg6->sockClient),ID);
			if(flag==1)
			{
				dlg6->EditInPut("��ȨID����ɹ�");
			}
			else
				dlg6->EditInPut("��ȨID����ʧ��");
		}
		else
			dlg6->EditInPut("�����ID������");
	}

}

void Cdlg6::OnButton5()
{
	if(dlg6->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag=ComDeleAuthoId(dlg6->hCom);
		if(flag==1)
			dlg6->EditInPut("��ȨIDɾ���ɹ�");
		else
			dlg6->EditInPut("��ȨIDɾ��ʧ��");
	}


	if (dlg6->sockClient!=INVALID_SOCKET)
	{
		int flag=SocketDeleAuthoId(&(dlg6->sockClient));
		if(flag==1)
			dlg6->EditInPut("��ȨIDɾ���ɹ�");
		else
			dlg6->EditInPut("��ȨIDɾ��ʧ��");
	}
}