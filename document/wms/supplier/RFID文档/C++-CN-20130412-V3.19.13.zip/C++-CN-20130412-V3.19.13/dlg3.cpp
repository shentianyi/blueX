// dlg3.cpp : implementation file
//

#include "stdafx.h"
#include "EcpText.h"
#include "dlg3.h"
#include "EcpTextDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Cdlg3 dialog

CEcpTextDlg *dlg3;

Cdlg3::Cdlg3(CWnd* pParent /*=NULL*/)
	: CDialog(Cdlg3::IDD, pParent)
{
	//{{AFX_DATA_INIT(Cdlg3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Cdlg3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Cdlg3)
	DDX_Control(pDX, IDC_COMBO4, m_listbox4);
	DDX_Control(pDX, IDC_COMBO3, m_listbox3);
	DDX_Control(pDX, IDC_COMBO2, m_listbox2);
	DDX_Control(pDX, IDC_COMBO1, m_listbox1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Cdlg3, CDialog)
	//{{AFX_MSG_MAP(Cdlg3)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_CBN_SELCHANGE(IDC_COMBO2, OnSelchangeCombo2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cdlg3 message handlers

BOOL Cdlg3::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Init();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void Cdlg3::Init()
{
	dlg3=(CEcpTextDlg*)(AfxGetApp()->m_pMainWnd);
	
	m_listbox1.InsertString(0,"�ߵ�ƽ����");
	m_listbox1.InsertString(1,"�͵�ƽ����");

	m_listbox2.InsertString(0,"RS485");
	m_listbox2.InsertString(1,"Wiegand");
	m_listbox2.InsertString(2,"RS232");

	m_listbox4.InsertString(0,"Wiegand26");
	m_listbox4.InsertString(1,"Wiegand34");
	m_listbox4.InsertString(2,"Wiegand32");
	
	((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(TRUE);
}

void Cdlg3::ElementEnable(DWORD IDC,BOOL flag)
{
	CWnd *Element;
	Element = GetDlgItem(IDC);     //��ȡ�ؼ�ָ�룬IDC_EDIT1Ϊ�ؼ�ID��
	Element->EnableWindow(flag);
}

void Cdlg3::OnButton1() 
{
	ElementEnable(IDC_BUTTON1,FALSE);
	ReadParameter();
	ElementEnable(IDC_BUTTON1,TRUE);
}

void Cdlg3::ReadParameter()
{
	// TODO: Add your control notification handler code here
//*************************����**********************************
	if (dlg3->hCom!=INVALID_HANDLE_VALUE)
	{
		char  Length=12;
		uchar Lsb=0x70;
		uchar Writedata[20]={0};
		int flag;
		CString str;
		flag=ComQueryMultiParameter(dlg3->hCom,Length,Lsb,Writedata);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		//����
		if (Writedata[0]==1)
		{
			OnRadio1();
			((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
			((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
		}
		else if (Writedata[0]==2)
		{
			OnRadio2();
			((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);
			((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
		}
		else if (Writedata[0]==3)
		{
			((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(TRUE);
		}

		//����ʱ����
		str.Format("%d",Writedata[1]);
		SetDlgItemText(IDC_EDIT1,str);

		//��·ѡ��
		if (Writedata[2]>0&&Writedata[2]<4)
		{
			m_listbox2.SetCurSel(Writedata[2]-1);
			OnSelchangeCombo2();
		}

		//WiegandЭ��ѡ��
		if (Writedata[3]>0&&Writedata[3]<4)
		{
			m_listbox4.SetCurSel(Writedata[3]-1);
		}
		//Wiegand��������������
		str.Format("%d",Writedata[4]);
		SetDlgItemText(IDC_EDIT5,str);

		//Wiegand���������������
		str.Format("%d",Writedata[5]);
		SetDlgItemText(IDC_EDIT6,str);

		//WiegandЭ��ѡ��
		if (Writedata[8]>=0&&Writedata[8]<=9)
		{
			m_listbox3.SetCurSel(Writedata[8]);
		}

		//ID�����б�ʱ��
		str.Format("%d",Writedata[10]);
		SetDlgItemText(IDC_EDIT2,str);

		//ID�����б�
		if (Writedata[11]==1)
		{
			((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(TRUE);
			OnCheck1();
		}
		else
		{
			((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(FALSE);
			OnCheck1();
		}
		//�����ܽ����ô�������ģʽ����
		Lsb=0x80;
		flag=ComQuerySingleParameter(dlg3->hCom,Lsb,Writedata);
		if (flag==1)
		{
			if (Writedata[0]==0||Writedata[0]==1)
			{
				m_listbox1.SetCurSel(Writedata[0]);
			}
		}
		else
		{
			str.Format("��������ģʽ����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		

		//�ӳٹر�ʱ��
		Lsb=0x84;
		flag=ComQuerySingleParameter(dlg3->hCom,Lsb,Writedata);
		if (flag==1)
		{
			str.Format("�ӳٹر�ʱ��:%d",Writedata[0]);
			SetDlgItemText(IDC_EDIT3,str);
		}
		else
		{
			str.Format("%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		//�û�������
		Lsb=0x64;
		flag=ComQuerySingleParameter(dlg3->hCom,Lsb,Writedata);
		if (flag==1)
		{
			str.Format("%d",Writedata[0]);
			SetDlgItemText(IDC_EDIT4,str);
		}
		else
		{
			str.Format("�û�������:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		dlg3->EditInPut("����3 ��ȡ�����ɹ�");
	}

//*************************����**********************************
	else if (dlg3->sockClient!=INVALID_SOCKET)
	{
		char  Length=12;
		uchar Lsb=0x70;
		uchar Writedata[20]={0};
		int flag;
		CString str;
		flag=SocketQueryMultiParameter(&(dlg3->sockClient),Length,Lsb,Writedata);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		//����
		if (Writedata[0]==1)
		{
			OnRadio1();
			((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
			((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
		}
		else if (Writedata[0]==2)
		{
			OnRadio2();
			((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);
			((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
		}
		else if (Writedata[0]==3)
		{
			((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
			((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(TRUE);
		}

		//����ʱ����
		str.Format("%d",Writedata[1]);
		SetDlgItemText(IDC_EDIT1,str);

		//��·ѡ��
		if (Writedata[2]>0&&Writedata[2]<4)
		{
			m_listbox2.SetCurSel(Writedata[2]-1);
			OnSelchangeCombo2();
		}

		//WiegandЭ��ѡ��
		if (Writedata[3]>0&&Writedata[3]<4)
		{
			m_listbox4.SetCurSel(Writedata[3]-1);
		}
		//Wiegand��������������
		str.Format("%d",Writedata[4]);
		SetDlgItemText(IDC_EDIT5,str);

		//Wiegand���������������
		str.Format("%d",Writedata[5]);
		SetDlgItemText(IDC_EDIT6,str);

		//WiegandЭ��ѡ��
		if (Writedata[8]>=0&&Writedata[8]<=9)
		{
			m_listbox3.SetCurSel(Writedata[8]);
		}

		//ID�����б�ʱ��
		str.Format("%d",Writedata[10]);
		SetDlgItemText(IDC_EDIT2,str);

		//ID�����б�
		if (Writedata[11]==1)
		{
			((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(TRUE);
			OnCheck1();
		}
		else
		{
			((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(FALSE);
			OnCheck1();
		}
		//�����ܽ����ô�������ģʽ����
		Lsb=0x80;
		flag=SocketQuerySingleParameter(&(dlg3->sockClient),Lsb,Writedata);
		if (flag==1)
		{
			if (Writedata[0]==0||Writedata[0]==1)
			{
				m_listbox1.SetCurSel(Writedata[0]);
			}
		}
		else
		{
			str.Format("��������ģʽ����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		

		//�ӳٹر�ʱ��
		Lsb=0x84;
		flag=SocketQuerySingleParameter(&(dlg3->sockClient),Lsb,Writedata);
		if (flag==1)
		{
			str.Format("%d",Writedata[0]);
			SetDlgItemText(IDC_EDIT3,str);
		}
		else
		{
			str.Format("%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		//�û�������
		Lsb=0x64;
		flag=SocketQuerySingleParameter(&(dlg3->sockClient),Lsb,Writedata);
		if (flag==1)
		{
			str.Format("%d",Writedata[0]);
			SetDlgItemText(IDC_EDIT4,str);
		}
		else
		{
			str.Format("�û�������:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		dlg3->EditInPut("����3 ��ȡ�����ɹ�");
	}
	

	
	
}



void Cdlg3::OnCheck1() 
{
	// TODO: Add your control notification handler code here
	int flag=((CButton*)GetDlgItem(IDC_CHECK1))->GetState();
	if (flag==9||flag==1)
	{
		ElementEnable(IDC_EDIT2,TRUE);
	}
	else
	{
		ElementEnable(IDC_EDIT2,FALSE);
	}
}

void Cdlg3::OnButton2() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON2,FALSE);
	SetParameter();
	ElementEnable(IDC_BUTTON2,TRUE);
}

void Cdlg3::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,FALSE);
	ElementEnable(IDC_EDIT1,FALSE);
	ElementEnable(IDC_EDIT3,FALSE);
	RadioFlag=1;
}

void Cdlg3::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,FALSE);
	ElementEnable(IDC_EDIT1,TRUE);
	ElementEnable(IDC_EDIT3,FALSE);
	RadioFlag=2;
}

void Cdlg3::OnRadio3() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,TRUE);
	ElementEnable(IDC_EDIT1,TRUE);
	ElementEnable(IDC_EDIT3,TRUE);
	RadioFlag=3;
}

void Cdlg3::OnSelchangeCombo2() 
{
	// TODO: Add your control notification handler code here
	int flag=m_listbox2.GetCurSel();
	if (flag!=1)
	{
		ElementEnable(IDC_COMBO3,FALSE);
		ElementEnable(IDC_COMBO4,FALSE);
		ElementEnable(IDC_EDIT5,FALSE);
		ElementEnable(IDC_EDIT6,FALSE);
	}
	else
	{
		ElementEnable(IDC_COMBO3,TRUE);
		ElementEnable(IDC_COMBO4,TRUE);
		ElementEnable(IDC_EDIT5,TRUE);
		ElementEnable(IDC_EDIT6,TRUE);
	}
}

void Cdlg3::SetParameter()
{
	if (dlg3->hCom!=INVALID_HANDLE_VALUE)
	{
		char  Length=6;
		uchar Lsb=0x70;
		uchar Writedata[20]={0};
		int flag;
		CString str;
		
		Writedata[0]=RadioFlag;
		Writedata[1]=GetDlgItemInt(IDC_EDIT1);
		Writedata[2]=m_listbox2.GetCurSel()+1;
		Writedata[3]=m_listbox4.GetCurSel()+1;
		Writedata[4]=GetDlgItemInt(IDC_EDIT5);
		Writedata[5]=GetDlgItemInt(IDC_EDIT6);

		if (Writedata[2]!=2)
		{
			Length=3;
		}


		flag=ComSetMultiParameter(dlg3->hCom,Length,Lsb,Writedata);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}


		//Wiegandȡλ
		Lsb=0x78;
		Writedata[0]=m_listbox3.GetCurSel();
		flag=ComSetSingleParameter(dlg3->hCom,Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("Wiegandȡλ:%d",flag);
			dlg3->EditInPut(str);
			return;
		}


		

		if (((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck())
		{
			Writedata[0]=1;
		}
		else
		{
			Writedata[0]=2;
		}
		
		//ID�����б�����
		Lsb=0x7b;
		flag=ComSetSingleParameter(dlg3->hCom,Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("ID�����б�����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		//ID�����б�ʱ��
		
		if (Writedata[0]==1)
		{
			Lsb=0x7a;
			Writedata[0]=GetDlgItemInt(IDC_EDIT2);
			flag=ComSetSingleParameter(dlg3->hCom,Lsb,Writedata[0]);//��ѯ�������
			if (flag==1)
			{
				;//AfxMessageBox("��ȡ������ɹ�");
			}
			else
			{
				str.Format("�����б�ʱ��:%d",flag);
				dlg3->EditInPut(str);
				return;
			}
		}

		//��������ģʽ����
		Lsb=0x80;
		Writedata[0]=m_listbox1.GetCurSel();
		flag=ComSetSingleParameter(dlg3->hCom,Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("��������ģʽ����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		
		//�ӳٹر�ʱ��
		Lsb=0x84;
		Writedata[0]=GetDlgItemInt(IDC_EDIT3);
		flag=ComSetSingleParameter(dlg3->hCom,Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�ӳٹر�ʱ��:%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		//�ӳٹر�ʱ��
		Lsb=0x64;
		Writedata[0]=GetDlgItemInt(IDC_EDIT4);
		flag=ComSetSingleParameter(dlg3->hCom,Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�û���:%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		dlg3->EditInPut("����3 �������óɹ�");
	}

//****************************************************************

	if (dlg3->sockClient!=INVALID_SOCKET)
	{
		char  Length=6;
		uchar Lsb=0x70;
		uchar Writedata[20]={0};
		int flag;
		CString str;
		
		Writedata[0]=RadioFlag;
		Writedata[1]=GetDlgItemInt(IDC_EDIT1);
		Writedata[2]=m_listbox2.GetCurSel()+1;
		Writedata[3]=m_listbox4.GetCurSel()+1;
		Writedata[4]=GetDlgItemInt(IDC_EDIT5);
		Writedata[5]=GetDlgItemInt(IDC_EDIT6);

		if (Writedata[2]==2)
		{
			Length=3;
		}


		flag=SocketSetMultiParameter(&(dlg3->sockClient),Length,Lsb,Writedata);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}


		//Wiegandȡλ
		Lsb=0x78;
		Writedata[0]=m_listbox3.GetCurSel();
		flag=SocketSetSingleParameter(&(dlg3->sockClient),Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("Wiegandȡλ:%d",flag);
			dlg3->EditInPut(str);
			return;
		}


		

		if (((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck())
		{
			Writedata[0]=1;
		}
		else
		{
			Writedata[0]=2;
		}
		
		//ID�����б�����
		Lsb=0x7b;
		flag=SocketSetSingleParameter(&(dlg3->sockClient),Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("ID�����б�����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		//ID�����б�ʱ��
		
		if (Writedata[0]==1)
		{
			Lsb=0x7a;
			Writedata[0]=GetDlgItemInt(IDC_EDIT2);
			flag=SocketSetSingleParameter(&(dlg3->sockClient),Lsb,Writedata[0]);//��ѯ�������
			if (flag==1)
			{
				;//AfxMessageBox("��ȡ������ɹ�");
			}
			else
			{
				str.Format("�����б�ʱ��:%d",flag);
				dlg3->EditInPut(str);
				return;
			}
		}

		//��������ģʽ����
		Lsb=0x80;
		Writedata[0]=m_listbox1.GetCurSel();
		flag=SocketSetSingleParameter(&(dlg3->sockClient),Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("��������ģʽ����:%d",flag);
			dlg3->EditInPut(str);
			return;
		}
		
		//�ӳٹر�ʱ��
		Lsb=0x84;
		Writedata[0]=GetDlgItemInt(IDC_EDIT3);
		flag=SocketSetSingleParameter(&(dlg3->sockClient),Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�ӳٹر�ʱ��:%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		//�ӳٹر�ʱ��
		Lsb=0x64;
		Writedata[0]=GetDlgItemInt(IDC_EDIT4);
		flag=SocketSetSingleParameter(&(dlg3->sockClient),Lsb,Writedata[0]);//��ѯ�������
		if (flag==1)
		{
			;//AfxMessageBox("��ȡ������ɹ�");
		}
		else
		{
			str.Format("�û���:%d",flag);
			dlg3->EditInPut(str);
			return;
		}

		dlg3->EditInPut("����3 �������óɹ�");
	}
}

void Cdlg3::OnButton3() 
{
	// TODO: Add your control notification handler code here
	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
	OnRadio2();
	SetDlgItemText(IDC_EDIT1,"15");
	((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(FALSE);
	OnCheck1();
	SetDlgItemText(IDC_EDIT2,"10");
	m_listbox1.SetCurSel(0);
	SetDlgItemText(IDC_EDIT3,"10");
	SetDlgItemText(IDC_EDIT4,"255");
	m_listbox2.SetCurSel(1);
	OnSelchangeCombo2();
	((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(FALSE);
	m_listbox3.SetCurSel(0);
	m_listbox4.SetCurSel(0);
	SetDlgItemText(IDC_EDIT5,"8");
	SetDlgItemText(IDC_EDIT6,"12");

}
