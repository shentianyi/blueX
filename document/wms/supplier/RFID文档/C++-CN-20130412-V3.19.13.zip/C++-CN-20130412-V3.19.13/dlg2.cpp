// dlg2.cpp : implementation file
//

#include "stdafx.h"
#include "EcpText.h"
#include "dlg2.h"
#include "EcpTextDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Cdlg2 dialog

CEcpTextDlg *dlg2;

Cdlg2::Cdlg2(CWnd* pParent /*=NULL*/)
	: CDialog(Cdlg2::IDD, pParent)
{
	//{{AFX_DATA_INIT(Cdlg2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Cdlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Cdlg2)
	DDX_Control(pDX, IDC_COMBO3, m_listbox3);
	DDX_Control(pDX, IDC_COMBO2, m_listbox2);
	DDX_Control(pDX, IDC_COMBO1, m_listbox1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Cdlg2, CDialog)
	//{{AFX_MSG_MAP(Cdlg2)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cdlg2 message handlers


BOOL Cdlg2::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Init();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void Cdlg2::Init()
{
	dlg2=(CEcpTextDlg*)(AfxGetApp()->m_pMainWnd);

	m_listbox1.InsertString(0,"������");
	m_listbox1.InsertString(1,"EPC");
	m_listbox1.InsertString(2,"TID");
	m_listbox1.InsertString(3,"�û���");
	m_listbox1.SetCurSel(1);
	SetDlgItemText(IDC_EDIT1,"2");
	SetDlgItemText(IDC_EDIT2,"1");


	m_listbox2.InsertString(0,"LOCK USER");
	m_listbox2.InsertString(1,"LOCK TID");
	m_listbox2.InsertString(2,"EPC");
	m_listbox2.InsertString(3,"ACCESS");
	m_listbox2.InsertString(4,"KILL");
	m_listbox2.InsertString(5,"ALL");
	m_listbox2.SetCurSel(2);
	SetDlgItemText(IDC_EDIT4,"19");


	m_listbox3.InsertString(0,"������");
	m_listbox3.InsertString(1,"EPC");
	m_listbox3.InsertString(2,"TID");
	m_listbox3.InsertString(3,"�û���");
	m_listbox3.SetCurSel(1);
	SetDlgItemText(IDC_EDIT6,"2");

	SetDlgItemText(IDC_EDIT7,"1234");


}

void Cdlg2::OnButton1() 
{
	// TODO: Add your control notification handler code here
	if (dlg2->hCom!=INVALID_HANDLE_VALUE)
	{
		char Membank=m_listbox1.GetCurSel();
		char Address=GetDlgItemInt(IDC_EDIT1);
		int Length=GetDlgItemInt(IDC_EDIT2);
		unsigned char buf[100]={0};
		CString str,str2;
		int flag;
		int cout=5;
		while(cout--)
		{
			flag=ComReadTagContent(dlg2->hCom,Membank,Address,Length,buf);
			if (flag==1)
				break;
		}
		
		if (flag==1)
		{
			for (int i=0;i<Length*2;i++)
			{
				str2.Format("%02X",buf[i]);
				str+=str2;
			}
			
			SetDlgItemText(IDC_EDIT3,str);
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);	
		}
	}
	if (dlg2->sockClient!=INVALID_SOCKET)
	{
		char Membank=m_listbox1.GetCurSel();
		char Address=GetDlgItemInt(IDC_EDIT1);
		int Length=GetDlgItemInt(IDC_EDIT2);
		unsigned char buf[10]={0};
		CString str,str2;
		int flag;
		int cout=5;
		while(cout--)
		{
			flag=SocketReadTagContent(&(dlg2->sockClient),Membank,Address,Length,buf);
			if (flag==1)
				break;
		}
		
		if (flag==1)
		{
			for (int i=0;i<Length*2;i++)
			{
			str2.Format("%02X",buf[i]);
			str+=str2;
			}
			SetDlgItemText(IDC_EDIT3,str);
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);	
		}
	}
}

void Cdlg2::OnButton2() 
{
	// TODO: Add your control notification handler code here
	if (dlg2->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag;
		CString str;

		flag=ComInitTag(dlg2->hCom);
		if (flag==1)
		{
			AfxMessageBox("��ʼ�����ݳɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);
		}
	}
	else if (dlg2->sockClient!=INVALID_SOCKET)
	{
		int flag;
		CString str;
		
		flag=SocketInitTag(&(dlg2->sockClient));
		if (flag==1)
		{
			AfxMessageBox("��ʼ�����ݳɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);
		}
	}
}

void Cdlg2::OnButton3() 
{
	// TODO: Add your control notification handler code here
	if (dlg2->hCom!=INVALID_HANDLE_VALUE)
	{
		int flag,LockType;
		CString str;
		LockType=m_listbox2.GetCurSel();
		flag=ComTagLock(dlg2->hCom,LockType);
		if (flag==1)
		{
			AfxMessageBox("������ǩ�ɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);
		}
	}
	else if (dlg2->sockClient!=INVALID_SOCKET)
	{
		int flag,LockType;
		CString str;
		LockType=m_listbox2.GetCurSel();
		flag=SocketTagLock(&(dlg2->sockClient),LockType);
		if (flag==1)
		{
			AfxMessageBox("������ǩ�ɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);
		}
	}
}

void Cdlg2::OnButton4() 
{
	// TODO: Add your control notification handler code here
	
}

void Cdlg2::OnButton5() 
{
	// TODO: Add your control notification handler code here
	int flag;
	CString str,stri;
	unsigned char Data[20]={0};
	char MemBank=m_listbox3.GetCurSel();
	char Address=GetDlgItemInt(IDC_EDIT6);
	GetDlgItemText(IDC_EDIT7,stri);
	int WriteLength=strlen(stri)/2;
	
	for (int i=0;i<WriteLength;i++)
	{
		Data[i]=CharToHex((uchar)stri[i*2])*16+CharToHex((uchar)stri[i*2+1]);
	}

	if (dlg2->hCom!=INVALID_HANDLE_VALUE)
	{
		
		if (WriteLength>2)
			flag=ComTagWriteWord(dlg2->hCom,1,MemBank,Address,WriteLength/2,Data);//д������
		else
			flag=ComTagWriteWord(dlg2->hCom,0,MemBank,Address,WriteLength/2,Data);//д������
		
		if (flag==1)
		{
			;//AfxMessageBox("д���ǩ�ɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);
		}
	}
	else if (dlg2->sockClient!=INVALID_SOCKET)
	{
/*

		int flag;
		CString str,stri;
		unsigned char Data[2]={0};
		char MemBank=m_listbox3.GetCurSel();
		char Address=GetDlgItemInt(IDC_EDIT6);
		GetDlgItemText(IDC_EDIT7,stri);
		if (strlen(stri)!=4)
		{
			AfxMessageBox("������4λ:1-9����A-F");
		}
		
		Data[0]=CharToHex((uchar)stri[0])*16+CharToHex((uchar)stri[1]);
		Data[1]=CharToHex((uchar)stri[2])*16+CharToHex((uchar)stri[3]);
		*/
		if (WriteLength>2)
			flag=SocketTagWriteWord(&(dlg2->sockClient),1,MemBank,Address,WriteLength/2,Data);//д������
		else
			flag=SocketTagWriteWord(&(dlg2->sockClient),0,MemBank,Address,WriteLength/2,Data);//д������
		if (flag==1)
		{
			;//AfxMessageBox("д���ǩ�ɹ�");
		}
		else
		{
			str.Format("%d",flag);
			dlg2->EditInPut(str);
		}
	}
}
