// dlg4.cpp : implementation file
//

#include "stdafx.h"
#include "EcpText.h"
#include "EcpTextDlg.h"
#include "dlg4.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Cdlg4 dialog

CEcpTextDlg *dlg4;

Cdlg4::Cdlg4(CWnd* pParent /*=NULL*/)
	: CDialog(Cdlg4::IDD, pParent)
{
	//{{AFX_DATA_INIT(Cdlg4)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Cdlg4::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Cdlg4)
	DDX_Control(pDX, IDC_COMBO1, m_listbox1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Cdlg4, CDialog)
	//{{AFX_MSG_MAP(Cdlg4)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_RADIO5, OnRadio5)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Cdlg4 message handlers

BOOL Cdlg4::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	Init();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void Cdlg4::Init()
{
	int i;
	CString str;
	dlg4=(CEcpTextDlg*)(AfxGetApp()->m_pMainWnd);
	
	for (i=0;i<50;i++)
	{
		str.Format("%d--%0.2fMHz",i+1,920.50+0.25*i);
		m_listbox1.InsertString(i,str);
	}
	m_listbox1.SetCurSel(0);

	for (i=0;i<=49;i++)
	{
		str.Format("Ƶ��%d",i+1);
		SetDlgItemText(IDC_CHECK5+i,str);
	}
	
}

void Cdlg4::ElementEnable(DWORD IDC,BOOL flag)
{
	CWnd *Element;
	Element = GetDlgItem(IDC);     //��ȡ�ؼ�ָ�룬IDC_EDIT1Ϊ�ؼ�ID��
	Element->EnableWindow(flag);
}

void Cdlg4::OnButton1() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON1,FALSE);
	ReadParameter();
	ElementEnable(IDC_BUTTON1,TRUE);
}

void Cdlg4::ReadParameter()
{
	if (dlg4->hCom!=INVALID_HANDLE_VALUE)
	{
		CString str;
		int flag,i,j;
		int Length;
		uchar temp;
		uchar Lsb=0x65;
		unsigned char recvbuf[20]={0};

		//���书��
		flag=ComQuerySingleParameter(dlg4->hCom,Lsb,recvbuf);
		if (flag==1)
		{
			str.Format("%d",recvbuf[0]);
			SetDlgItemText(IDC_EDIT1,str);
		}
		else
		{
			str.Format("���书��:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		Lsb=0x87;
		flag=ComQuerySingleParameter(dlg4->hCom,Lsb,recvbuf);
		if (flag==1)
		{
			if (recvbuf[0]==0)
			{
				((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
				((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO5))->SetCheck(FALSE);
				OnRadio1();
			}
			else if(recvbuf[0]==1)
			{
				((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);
				((CButton*)GetDlgItem(IDC_RADIO5))->SetCheck(FALSE);
				OnRadio2();
			}
			else if(recvbuf[0]==2)
			{
				((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO5))->SetCheck(TRUE);
				OnRadio5();
			}
			else
			{
				str.Format("��ǩ:%d",recvbuf[0]);
				dlg4->EditInPut(str);
				return;
			}
			
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		//��Ƶ����
		Lsb=0x90;
		flag=ComQuerySingleParameter(dlg4->hCom,Lsb,recvbuf);
		if (flag==1)
		{
			if (recvbuf[0]==0)//��Ƶ������ʽ
			{
				OnRadio4();
				((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(TRUE);
				
			}
			else//�̶�Ƶ�ʹ�����ʽ
			{
				OnRadio3();
				((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(TRUE);
				((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(FALSE);
				m_listbox1.SetCurSel(recvbuf[0]-1);
			}
			
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}
		
		//��Ƶ����
		Lsb=0x92;
		Length=7;
		flag=ComQueryMultiParameter(dlg4->hCom,Length,Lsb,recvbuf);
		if (flag==1)
		{
			for (i=0;i<6;i++)
			{
				temp=recvbuf[i];
				for (j=0;j<8;j++)
				{
					if (temp&0x01)
						((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(1);
					else
						((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(0);
					temp=temp>>1;
				}
			}
			temp=recvbuf[i];
			for (j=0;j<2;j++)
			{
				if (temp&0x01)
					((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(1);
				else
					((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(0);
				temp=temp>>1;
			}
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}
		
		//����ѡ��
		Lsb=0x8a;
		flag=ComQuerySingleParameter(dlg4->hCom,Lsb,recvbuf);
		if (flag==1)
		{
			temp=recvbuf[0];
			for (i=0;i<4;i++)
			{
				if (temp&0x01)
					((CButton*)GetDlgItem(IDC_CHECK1+i))->SetCheck(1);		
				else
					((CButton*)GetDlgItem(IDC_CHECK1+i))->SetCheck(0);
				temp=temp>>1;
			}
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		dlg4->EditInPut("����4 ��ȡ�����ɹ�");
	}

//*********************************************************************


if (dlg4->sockClient!=INVALID_SOCKET)
	{
		CString str;
		int flag,i,j;
		int Length;
		uchar temp;
		uchar Lsb=0x65;
		unsigned char recvbuf[20]={0};

		//���书��
		flag=SocketQuerySingleParameter(&(dlg4->sockClient),Lsb,recvbuf);
		if (flag==1)
		{
			str.Format("%d",recvbuf[0]);
			SetDlgItemText(IDC_EDIT1,str);
		}
		else
		{
			str.Format("���书��:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		Lsb=0x87;
		flag=SocketQuerySingleParameter(&(dlg4->sockClient),Lsb,recvbuf);
		if (flag==1)
		{
			if (recvbuf[0]==0)
			{
				((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
				((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO5))->SetCheck(FALSE);
				OnRadio1();
			}
			else if(recvbuf[0]==1)
			{
				((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(TRUE);
				((CButton*)GetDlgItem(IDC_RADIO5))->SetCheck(FALSE);
				OnRadio2();
			}
			else if(recvbuf[0]==2)
			{
				((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO5))->SetCheck(TRUE);
				OnRadio5();
			}
			else
			{
				str.Format("��ǩ:%d",recvbuf[0]);
				dlg4->EditInPut(str);
				return;
			}
			
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		//��Ƶ����
		Lsb=0x90;
		flag=SocketQuerySingleParameter(&(dlg4->sockClient),Lsb,recvbuf);
		if (flag==1)
		{
			if (recvbuf[0]==0)//��Ƶ������ʽ
			{
				OnRadio4();
				((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
				((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(TRUE);
				
			}
			else//�̶�Ƶ�ʹ�����ʽ
			{
				OnRadio3();
				((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(TRUE);
				((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(FALSE);
				m_listbox1.SetCurSel(recvbuf[0]-1);
			}
			
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}
		
		//��Ƶ����
		Lsb=0x92;
		Length=7;
		flag=SocketQueryMultiParameter(&(dlg4->sockClient),Length,Lsb,recvbuf);
		if (flag==1)
		{
			for (i=0;i<6;i++)
			{
				temp=recvbuf[i];
				for (j=0;j<8;j++)
				{
					if (temp&0x01)
						((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(1);
					else
						((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(0);
					temp=temp>>1;
				}
			}
			temp=recvbuf[i];
			for (j=0;j<2;j++)
			{
				if (temp&0x01)
					((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(1);
				else
					((CButton*)GetDlgItem(IDC_CHECK5+j+i*8))->SetCheck(0);
				temp=temp>>1;
			}
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}
		//����
		Lsb=0x8a;
		flag=SocketQuerySingleParameter(&(dlg4->sockClient),Lsb,recvbuf);
		if (flag==1)
		{
			temp=recvbuf[0];
			for (i=0;i<4;i++)
			{
				if (temp&0x01)
					((CButton*)GetDlgItem(IDC_CHECK1+i))->SetCheck(1);		
				else
					((CButton*)GetDlgItem(IDC_CHECK1+i))->SetCheck(0);
				temp=temp>>1;
			}
		}
		else
		{
			str.Format("��ǩ:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		dlg4->EditInPut("����4 ��ȡ�����ɹ�");
	}
	

}

void Cdlg4::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	RadioFlag=0;
}

void Cdlg4::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	RadioFlag=1;
}

void Cdlg4::OnRadio5() 
{
	// TODO: Add your control notification handler code here
	RadioFlag=2;
}


void Cdlg4::OnRadio3() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,TRUE);
	for (int i=0;i<50;i++)
	{
		ElementEnable(IDC_CHECK5+i,FALSE);
	}
}

void Cdlg4::OnRadio4() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_COMBO1,FALSE);
	for (int i=0;i<50;i++)
	{
		ElementEnable(IDC_CHECK5+i,TRUE);
	}
}

void Cdlg4::OnButton2() 
{
	// TODO: Add your control notification handler code here
	ElementEnable(IDC_BUTTON2,FALSE);
	SetParameter();
	ElementEnable(IDC_BUTTON2,TRUE);
	
}

void Cdlg4::SetParameter()
{
	if (dlg4->hCom!=INVALID_HANDLE_VALUE)
	{
		CString str;
		int flag,i,j;
		int Length;
		uchar Lsb=0x65;
		unsigned char writebuf[20]={0};
		
		//���书��
		writebuf[0]=GetDlgItemInt(IDC_EDIT1);
		flag=ComSetSingleParameter(dlg4->hCom,Lsb,writebuf[0]);
		if (flag==1)
		{
			;
		}
		else
		{
			str.Format("���书��:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		//���࿨ѡ��
		Lsb=0x87;
		writebuf[0]=RadioFlag;
		flag=ComSetSingleParameter(dlg4->hCom,Lsb,writebuf[0]);
		if (flag==1)
		{
			;
		}
		else
		{
			str.Format("���࿨ѡ��:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		//��Ƶ����
		if(((CButton*)GetDlgItem(IDC_RADIO3))->GetCheck())
		{
			Lsb=0x90;
			writebuf[0]=m_listbox1.GetCurSel()+1;
			flag=ComSetSingleParameter(dlg4->hCom,Lsb,writebuf[0]);
			if (flag==1)
			{
				;
			}
			else
			{
				str.Format("��Ƶ����:%d",flag);
				dlg4->EditInPut(str);
				return;
			}
		}
		else//��Ƶ����
		{
			Lsb=0x90;
			writebuf[0]=0;
			flag=ComSetSingleParameter(dlg4->hCom,Lsb,writebuf[0]);
			if (flag==1)
			{
				;
			}
			else
			{
				str.Format("��Ƶ����:%d",flag);
				dlg4->EditInPut(str);
				return;
			}

			Length=7;
			Lsb=0x92;
			writebuf[0]=0;
			for (i=0;i<50;i++)
			{
				flag=((CButton*)GetDlgItem(IDC_CHECK5+i))->GetState();
				j=i/8;
				writebuf[j]=writebuf[j]>>1;
				if (flag>0)
				{
					writebuf[j]+=0x80;
				}
			}
			writebuf[6]=writebuf[6]>>6;
			flag=ComSetMultiParameter(dlg4->hCom,Length,Lsb,writebuf);
			if (flag==1)
			{
				;
			}
			else
			{
				str.Format("��Ƶ����:%d",flag);
				dlg4->EditInPut(str);
				return;
			}
		}

		//��������
		int tianxian=0;
		writebuf[0]=0;
		for (i=0;i<4;i++)
		{
			writebuf[0]=writebuf[0]>>1;
			flag=((CButton*)GetDlgItem(IDC_CHECK1+i))->GetState();
			if (flag>0)
			{
				tianxian++;
				writebuf[0]+=0x08;
			}
			
		}
		if (tianxian==1)
		{
			Lsb=0x89;
			flag=ComSetSingleParameter(dlg4->hCom,Lsb,1);
		}
		else if(tianxian>1)
		{
			Lsb=0x89;
			flag=ComSetSingleParameter(dlg4->hCom,Lsb,4);
		}
		Lsb=0x8A;
		flag=ComSetSingleParameter(dlg4->hCom,Lsb,writebuf[0]);
		if (flag==1)
		{
			;
		}
		else
		{
			str.Format("��������:%d",flag);
			dlg4->EditInPut(str);
			return;
		}


		dlg4->EditInPut("����4 ���ò����ɹ�");
	}

//**************************************************************
if (dlg4->sockClient!=INVALID_SOCKET)
	{
		CString str;
		int flag,i,j;
		int Length;
		uchar Lsb=0x65;
		unsigned char writebuf[20]={0};
		
		//���书��
		writebuf[0]=GetDlgItemInt(IDC_EDIT1);
		flag=SocketSetSingleParameter(&(dlg4->sockClient),Lsb,writebuf[0]);
		if (flag==1)
		{
			;
		}
		else
		{
			str.Format("���书��:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		//���࿨ѡ��
		Lsb=0x87;
		writebuf[0]=RadioFlag;
		flag=SocketSetSingleParameter(&(dlg4->sockClient),Lsb,writebuf[0]);
		if (flag==1)
		{
			;
		}
		else
		{
			str.Format("���࿨ѡ��:%d",flag);
			dlg4->EditInPut(str);
			return;
		}

		//��Ƶ����
		if(((CButton*)GetDlgItem(IDC_RADIO3))->GetCheck())
		{
			Lsb=0x90;
			writebuf[0]=m_listbox1.GetCurSel()+1;
			flag=SocketSetSingleParameter(&(dlg4->sockClient),Lsb,writebuf[0]);
			if (flag==1)
			{
				;
			}
			else
			{
				str.Format("��Ƶ����:%d",flag);
				dlg4->EditInPut(str);
				return;
			}
		}
		else//��Ƶ����
		{
			Lsb=0x90;
			writebuf[0]=0;
			flag=SocketSetSingleParameter(&(dlg4->sockClient),Lsb,writebuf[0]);
			if (flag==1)
			{
				;
			}
			else
			{
				str.Format("��Ƶ����:%d",flag);
				dlg4->EditInPut(str);
				return;
			}

			Length=7;
			Lsb=0x92;
			writebuf[0]=0;
			for (i=0;i<50;i++)
			{
				flag=((CButton*)GetDlgItem(IDC_CHECK5+i))->GetState();
				j=i/8;
				writebuf[j]=writebuf[j]>>1;
				if (flag>0)
				{
					writebuf[j]+=0x80;
				}
			}
			writebuf[6]=writebuf[6]>>6;
			flag=SocketSetMultiParameter(&(dlg4->sockClient),Length,Lsb,writebuf);
			if (flag==1)
			{
				;
			}
			else
			{
				str.Format("��Ƶ����:%d",flag);
				dlg4->EditInPut(str);
				return;
			}
		}

		//��������
		int tianxian=0;
		writebuf[0]=0;
		for (i=0;i<4;i++)
		{
			writebuf[0]=writebuf[0]>>1;
			flag=((CButton*)GetDlgItem(IDC_CHECK1+i))->GetState();
			if (flag>0)
			{
				tianxian++;
				writebuf[0]+=0x08;
			}
			
		}
		if (tianxian==1)
		{
			Lsb=0x89;
			flag=SocketSetSingleParameter(&(dlg4->sockClient),Lsb,1);
		}
		else if(tianxian>1)
		{
			Lsb=0x89;
			flag=SocketSetSingleParameter(&(dlg4->sockClient),Lsb,4);
		}
		Lsb=0x8A;
		flag=SocketSetSingleParameter(&(dlg4->sockClient),Lsb,writebuf[0]);
		if (flag==1)
		{
			;
		}
		else
		{
			str.Format("��������:%d",flag);
			dlg4->EditInPut(str);
			return;
		}


		dlg4->EditInPut("����4 ���ò����ɹ�");
	}

}


void Cdlg4::OnButton3() 
{
	// TODO: Add your control notification handler code here
	SetDlgItemText(IDC_EDIT1,"120");
	((CButton*)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_RADIO2))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_RADIO5))->SetCheck(FALSE);
	OnRadio1();
	((CButton*)GetDlgItem(IDC_RADIO4))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_RADIO3))->SetCheck(FALSE);
	OnRadio4();
	((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK4))->SetCheck(FALSE);
	
	for (int i=0;i<50;i++)
		((CButton*)GetDlgItem(IDC_CHECK5+i))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK5+0))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK5+10))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK5+20))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK5+30))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK5+40))->SetCheck(TRUE);
	
	
}
