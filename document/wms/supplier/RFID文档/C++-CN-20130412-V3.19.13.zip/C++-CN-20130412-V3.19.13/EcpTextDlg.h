// EcpTextDlg.h : header file
//

#if !defined(AFX_ECPTEXTDLG_H__E46A6447_94BC_44AC_B4C8_6ABA613D8EC6__INCLUDED_)
#define AFX_ECPTEXTDLG_H__E46A6447_94BC_44AC_B4C8_6ABA613D8EC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CEcpTextDlg dialog
#include "dlg1.h"
#include "dlg2.h"
#include "dlg3.h"
#include "dlg4.h"
#include "dlg5.h"
#include "dlg6.h"

class CEcpTextDlg : public CDialog
{
// Construction
public:
	CEcpTextDlg(CWnd* pParent = NULL);	// standard constructor
	
public:
	HANDLE hCom;
	Cdlg1 dlg1;
	Cdlg2 dlg2;
	Cdlg3 dlg3;
	Cdlg4 dlg4;
	Cdlg5 dlg5;
	Cdlg6 dlg6;
	BOOL MuitFlag;

public:
	int HeartCout;
	SOCKET sockClient;
	void Init();
	void ElementEnable(DWORD IDC,BOOL flag);
	void ElementShow(DWORD IDC,BOOL flag);
	void EditInPut(CString str);
// Dialog Data
	//{{AFX_DATA(CEcpTextDlg)
	enum { IDD = IDD_ECPTEXT_DIALOG };
	CComboBox	m_listbox1;
	CTabCtrl	m_tab1;
	CEdit	m_edit7;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEcpTextDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CEcpTextDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnSelchangeTab1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadio3();
	afx_msg void OnButton7();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnButton8();
	afx_msg void OnButton5();
	afx_msg void OnButton6();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ECPTEXTDLG_H__E46A6447_94BC_44AC_B4C8_6ABA613D8EC6__INCLUDED_)
