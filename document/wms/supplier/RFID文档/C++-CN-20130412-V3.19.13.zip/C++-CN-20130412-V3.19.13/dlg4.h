#if !defined(AFX_DLG4_H__AD6D2D19_9D6C_4041_96D4_7E843B8D14DC__INCLUDED_)
#define AFX_DLG4_H__AD6D2D19_9D6C_4041_96D4_7E843B8D14DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlg4.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Cdlg4 dialog

class Cdlg4 : public CDialog
{
// Construction
public:
	Cdlg4(CWnd* pParent = NULL);   // standard constructor

public:
	void ElementEnable(DWORD IDC,BOOL flag);
	void ReadParameter();
	void Init();

public:
	void SetParameter();
	int RadioFlag;
// Dialog Data
	//{{AFX_DATA(Cdlg4)
	enum { IDD = IDD_DIALOG4 };
	CComboBox	m_listbox1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Cdlg4)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Cdlg4)
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio1();
	afx_msg void OnRadio2();
	afx_msg void OnRadio3();
	afx_msg void OnRadio4();
	afx_msg void OnButton2();
	afx_msg void OnRadio5();
	afx_msg void OnButton3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG4_H__AD6D2D19_9D6C_4041_96D4_7E843B8D14DC__INCLUDED_)
