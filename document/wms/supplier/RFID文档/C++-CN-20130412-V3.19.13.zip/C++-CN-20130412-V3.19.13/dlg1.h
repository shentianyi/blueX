#if !defined(AFX_DLG1_H__F224DA65_0676_43BA_8922_51A1156BA337__INCLUDED_)
#define AFX_DLG1_H__F224DA65_0676_43BA_8922_51A1156BA337__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlg1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Cdlg1 dialog

class Cdlg1 : public CDialog
{
// Construction
public:
	Cdlg1(CWnd* pParent = NULL);   // standard constructor
public:
	void EditInPut(CString str);
	void Init1();
	void ElementEnable(DWORD IDC,BOOL flag);
	void ComReadMuitTagBuf();
	void SocketReadMuitTagBuf();
public:
	int MulitNub;
// Dialog Data
	//{{AFX_DATA(Cdlg1)
	enum { IDD = IDD_DIALOG1 };
	CEdit	m_edit1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Cdlg1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Cdlg1)
	afx_msg void OnRadio1();
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio2();
	afx_msg void OnButton1();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG1_H__F224DA65_0676_43BA_8922_51A1156BA337__INCLUDED_)
