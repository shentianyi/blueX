#if !defined(AFX_DLG6_H__9BBA7DB3_3314_41F9_AE68_DBDD1485F705__INCLUDED_)
#define AFX_DLG6_H__9BBA7DB3_3314_41F9_AE68_DBDD1485F705__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// dlg6.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Cdlg6 dialog

class Cdlg6 : public CDialog
{
// Construction
public:
	void Init6();
	Cdlg6(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(Cdlg6)
	enum { IDD = IDD_DIALOG6 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Cdlg6)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Cdlg6)
	afx_msg void OnButton1();
	virtual BOOL OnInitDialog();
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnButton5();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG6_H__9BBA7DB3_3314_41F9_AE68_DBDD1485F705__INCLUDED_)
